package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

/**
 * Plays eerie sounds (ghast, enderman, warden) that have no business
 * being heard in a peaceful childhood world.
 * Starts after 5 minutes.
 */
@Environment(EnvType.CLIENT)
public class SoundAnomalyEvent extends HorrorEvent {

    public SoundAnomalyEvent() {
        super(6000); // 5 min
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(8000) == 0 && client.player != null) {
            playAnomalySound(client);
            activate(1, 7200, 14400); // instant event, 6–12 min cooldown
        }
    }

    private void playAnomalySound(MinecraftClient client) {
        float pitch  = 0.3f + random.nextFloat() * 0.5f;
        float volume = 0.25f + random.nextFloat() * 0.35f;

        switch (random.nextInt(5)) {
            case 0 -> client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_GHAST_AMBIENT, pitch, volume));

            case 1 -> client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_ENDERMAN_STARE, pitch, volume));

            case 2 -> client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_WARDEN_HEARTBEAT, pitch, volume));

            case 3 -> client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_PHANTOM_AMBIENT, pitch, volume * 0.4f));

            case 4 -> client.getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvents.ENTITY_ZOMBIE_AMBIENT, pitch * 0.5f, volume * 0.3f));
        }
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        // Audio-only event — no visual
    }
}
