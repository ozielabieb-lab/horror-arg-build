package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Always-on dark vignette framing the screen.
 * Pulses very slowly — barely noticeable at first, but once you see it
 * you can't un-see it.
 */
@Environment(EnvType.CLIENT)
public class VignetteEvent extends HorrorEvent {

    private long startTime;

    public VignetteEvent() {
        super(0);
        startTime = System.currentTimeMillis();
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        // Activate once, forever
        activate(Integer.MAX_VALUE, 0, 1);
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        if (!active) return;

        int w = screenW(client);
        int h = screenH(client);

        // Slow sine pulse: alpha oscillates between 0.55 and 0.80
        double elapsed = (System.currentTimeMillis() - startTime) / 1000.0;
        float pulse = (float)(0.675 + 0.125 * Math.sin(elapsed * 0.4));
        int maxA = (int)(pulse * 200);

        int vigW = w / 5;
        int vigH = h / 5;

        // Top → transparent
        context.fillGradient(0, 0, w, vigH, maxA << 24, 0x00000000);
        // Transparent ← Bottom
        context.fillGradient(0, h - vigH, w, h, 0x00000000, maxA << 24);

        // Left & right: layered fills for a pseudo-gradient
        int halfA = maxA / 2;
        context.fill(0,         0, vigW / 2, h, maxA  << 24);
        context.fill(vigW / 2,  0, vigW,     h, halfA << 24);
        context.fill(w - vigW,  0, w - vigW / 2, h, halfA << 24);
        context.fill(w - vigW / 2, 0, w,     h, maxA  << 24);
    }
}
