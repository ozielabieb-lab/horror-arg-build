package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * Sends a fake chat message from a mysterious sender.
 * Uses the real vanilla chat system so it looks completely authentic.
 * Starts after 5 minutes.
 */
@Environment(EnvType.CLIENT)
public class FakeChatEvent extends HorrorEvent {

    private static final String[] SENDERS = {
        "null",
        "_ _ _",
        "OldFriend2011",
        "e r r o r",
        "???",
        "\u2588\u2588\u2588\u2588",
        "SYSTEM",
    };

    private static final String[] MESSAGES = {
        "do you remember this place?",
        "you shouldn't have come back.",
        "i've been here the whole time.",
        "it knows you're here.",
        "why did you leave me?",
        "this isn't your world anymore.",
        "i remember when you used to play here.",
        "don't look for it.",
        "he is still here.",
        "the world remembers you.",
        "turn back. please.",
        "you were so young back then.",
        "i missed you.",
        "something is watching.",
        "why did you come back??",
        "i never left.",
        "it was always here.",
        "don't kill them.",
        "you can't leave.",
        "it sees everything you do.",
    };

    public FakeChatEvent() {
        super(6000); // 5 min
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(7200) == 0 && client.player != null) {
            sendFakeMessage(client);
            activate(1, 6000, 12000); // 5–10 min cooldown
        }
    }

    private void sendFakeMessage(MinecraftClient client) {
        String sender  = SENDERS[random.nextInt(SENDERS.length)];
        String message = MESSAGES[random.nextInt(MESSAGES.length)];

        // Occasionally use the player's own name as sender — very unsettling
        if (random.nextInt(5) == 0 && client.player != null) {
            sender = client.player.getName().getString();
        }

        String formatted = switch (random.nextInt(3)) {
            case 0 -> "\u00a77<\u00a7f" + sender + "\u00a77> \u00a77" + message;
            case 1 -> "\u00a78[\u00a77" + sender + "\u00a78] \u00a77" + message;
            default -> "\u00a77" + message; // No sender — just the words
        };

        client.player.sendMessage(Text.of(formatted), false);
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        // Vanilla chat handles the display
    }
}
