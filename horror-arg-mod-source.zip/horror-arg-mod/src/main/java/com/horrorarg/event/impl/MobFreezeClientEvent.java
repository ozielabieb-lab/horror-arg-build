package com.horrorarg.event.impl;

import com.horrorarg.HorrorArgMod;
import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Client-side visual companion to the server-side mob freeze.
 * When HorrorArgMod.mobsFrozen == true:
 *   - A barely-visible cold blue tint washes over the screen.
 *   - "..." pulses in the centre.
 * No timing logic here — it simply mirrors the server flag.
 */
@Environment(EnvType.CLIENT)
public class MobFreezeClientEvent extends HorrorEvent {

    private int blinkTick = 0;

    public MobFreezeClientEvent() {
        super(0);
        // Always "active" in the lifecycle sense; we gate rendering on the flag
        active                 = true;
        activeTicksRemaining   = Integer.MAX_VALUE;
        cooldownTicksRemaining = 0;
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        // Never triggers from here — always-on
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (HorrorArgMod.mobsFrozen) {
            blinkTick++;
        } else {
            blinkTick = 0;
        }
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        if (!HorrorArgMod.mobsFrozen) return;

        int w = screenW(client);
        int h = screenH(client);

        // Very subtle cold blue tint
        context.fill(0, 0, w, h, 0x0C002244);

        // Pulsing "..." in the vertical centre
        if (blinkTick % 40 < 20) {
            String dots = "...";
            int dw = client.textRenderer.getWidth(dots);
            context.drawText(client.textRenderer, dots,
                    (w - dw) / 2, h / 3,
                    0x66AACCFF, false);
        }
    }
}
