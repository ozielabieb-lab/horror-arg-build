package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/**
 * A full-screen dark overlay descends suddenly, turning noon into midnight.
 * Fake stars appear. A faint message is whispered.
 * Lasts 6–12 seconds. Starts after 8 minutes.
 */
@Environment(EnvType.CLIENT)
public class SkyDarkenEvent extends HorrorEvent {

    private int totalDuration;
    // Deterministic star positions (reset each activation)
    private final int[] starX = new int[80];
    private final int[] starY = new int[80];
    private final Random starRng = new Random(0xDEADBEEFL);

    private static final String[] WHISPERS = {
        "why is it dark?",
        "the sky forgot the sun.",
        "don't look up.",
        "they're watching from the dark.",
        "it remembers when this was daytime.",
    };
    private String whisper = "";

    public SkyDarkenEvent() {
        super(9600); // 8 min
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(18000) == 0) {
            totalDuration = 120 + random.nextInt(120); // 6–12 s
            whisper = WHISPERS[random.nextInt(WHISPERS.length)];

            // Re-randomise star positions each activation
            int w = screenW(client);
            int h = screenH(client);
            starRng.setSeed(gameTick);
            for (int i = 0; i < starX.length; i++) {
                starX[i] = starRng.nextInt(Math.max(1, w));
                starY[i] = starRng.nextInt(Math.max(1, h));
            }

            activate(totalDuration, 12000, 24000); // 10–20 min cooldown
        }
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        if (!active) return;

        int w = screenW(client);
        int h = screenH(client);

        float f = calcAlpha(totalDuration, 12, 12);
        int darkA = (int)(f * 225);

        // ── Dark overlay ──────────────────────────────────────────────────────
        context.fill(0, 0, w, h, (darkA << 24) | 0x000008);

        // ── Fake stars ────────────────────────────────────────────────────────
        if (darkA > 80) {
            for (int i = 0; i < starX.length; i++) {
                // Each star twinkles independently
                double twinkle = Math.sin(localTick * 0.12 + i * 1.7);
                int sa = (int)((darkA - 80) * 0.6 * (0.5 + 0.5 * twinkle));
                if (sa > 0)
                    context.fill(starX[i], starY[i], starX[i] + 1, starY[i] + 1,
                            (sa << 24) | 0xFFFFFF);
            }
        }

        // ── Whisper text ──────────────────────────────────────────────────────
        if (darkA > 140 && localTick > 18 && activeTicksRemaining > 18) {
            int tAlpha = Math.min(255, (darkA - 140) * 4);
            int tw = client.textRenderer.getWidth(whisper);
            context.drawText(client.textRenderer, whisper,
                    (w - tw) / 2, h / 2,
                    (tAlpha << 24) | 0x444444, false);
        }
    }
}
