package com.horrorarg.event;

import com.horrorarg.event.impl.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class EventManager {

    private final List<HorrorEvent> events = new ArrayList<>();
    private int gameTick = 0;

    public EventManager() {
        // Ordered by severity / intended appearance time
        events.add(new VignetteEvent());          // Always visible — subtle frame
        events.add(new GammaFlickerEvent());      // 3 min  — quick darkness flash
        events.add(new ActionBarGlitchEvent());   // 3 min  — cryptic action bar text
        events.add(new SoundAnomalyEvent());      // 5 min  — wrong ambient sounds
        events.add(new StaticOverlayEvent());     // 5 min  — TV static
        events.add(new FakeChatEvent());          // 5 min  — mysterious chat messages
        events.add(new CrypticTitleEvent());      // 10 min — title screen messages
        events.add(new ConsoleTextEvent());       // 10 min — fake error terminal
        events.add(new SkyDarkenEvent());         // 8 min  — sky goes black
        events.add(new FakeLoadingEvent());       // 15 min — fake saving/loading screen
        events.add(new MobFreezeClientEvent());   // always  — visual for server freeze
        events.add(new FakeDeathEvent());         // 30 min — fake death screen
    }

    public void tick(MinecraftClient client) {
        gameTick++;
        for (HorrorEvent e : events) {
            e.tick(client, gameTick);
        }
    }

    public void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;
        for (HorrorEvent e : events) {
            e.render(context, client);
        }
    }
}
