package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * Sends a cryptic message to the action bar (above the hotbar).
 * Very subtle — the player might think it was a real game message.
 * Starts after 3 minutes.
 */
@Environment(EnvType.CLIENT)
public class ActionBarGlitchEvent extends HorrorEvent {

    private static final String[] MESSAGES = {
        "...",
        "???",
        "do not look back.",
        "it's behind you.",
        "[CORRUPTED]",
        "you shouldn't be here.",
        "i see you.",
        "leave.",
        "don't.",
        "h e l p",
        "i remember you.",
        "stop.",
        "run.",
        "\u2588\u2588\u2588\u2588\u2588",          // block chars
        "null",
        "why did you come back?",
    };

    public ActionBarGlitchEvent() {
        super(3600); // 3 min
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(5000) == 0 && client.player != null) {
            String msg = MESSAGES[random.nextInt(MESSAGES.length)];
            // Grey colour so it blends in and looks almost like a system message
            client.player.sendMessage(Text.of("\u00a78" + msg), true);
            activate(40, 4800, 9600); // 2 s display, 4–8 min cooldown
        }
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        // No custom rendering — the vanilla action bar handles it
    }
}
