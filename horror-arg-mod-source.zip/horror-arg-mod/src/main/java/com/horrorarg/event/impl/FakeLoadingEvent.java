package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * A fake "Saving world..." screen overlays the game.
 * The world keeps running underneath — nothing actually saves.
 * Lasts 4–7 seconds. Starts after 15 minutes.
 */
@Environment(EnvType.CLIENT)
public class FakeLoadingEvent extends HorrorEvent {

    private static final String[] TEXTS = {
        "Saving world",
        "Loading terrain",
        "Generating world",
        "Building chunks",
        "Scanning entities",
        "Verifying world data",
        "Recovering lost data",
        "Defragmenting world",
        "Loading: OldWorld_2011 (1 of 1)",
        "Preparing spawn area: 100%",
        "ERROR: world.dat missing",
        "Restoring from backup",
        "Recalculating entity positions",
        "Resolving corrupted chunks",
    };

    private String text    = "";
    private int    dots    = 0;
    private int    totalDuration;

    public FakeLoadingEvent() {
        super(18000); // 15 min
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(20000) == 0) {
            text          = TEXTS[random.nextInt(TEXTS.length)];
            dots          = 0;
            totalDuration = 80 + random.nextInt(60); // 4–7 s
            activate(totalDuration, 18000, 30000);   // 15–25 min cooldown
        }
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (localTick % 10 == 0) dots = (dots + 1) % 4;
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        if (!active) return;

        int w = screenW(client);
        int h = screenH(client);

        float f  = calcAlpha(totalDuration, 8, 8);
        int   bg = (int)(f * 240);
        int   fg = (int)(f * 255);

        // ── Black background ──────────────────────────────────────────────────
        context.fill(0, 0, w, h, (bg << 24));

        // ── Loading text ──────────────────────────────────────────────────────
        String display = text + ".".repeat(dots);
        int tw = client.textRenderer.getWidth(display);
        context.drawText(client.textRenderer, display,
                (w - tw) / 2, h / 2 - 10,
                (fg << 24) | 0xFFFFFF, false);

        // ── Progress bar ──────────────────────────────────────────────────────
        int barW = w / 3;
        int barX = (w - barW) / 2;
        int barY = h / 2 + 10;
        float progress = (localTick % 60) / 60f;

        context.fill(barX,  barY, barX + barW, barY + 4, (fg << 24) | 0x333333);
        context.fill(barX,  barY, barX + (int)(barW * progress), barY + 4,
                (fg << 24) | 0xFFFFFF);

        // ── Percentage ────────────────────────────────────────────────────────
        String pct = (int)(progress * 100) + "%";
        int pw = client.textRenderer.getWidth(pct);
        context.drawText(client.textRenderer, pct,
                (w - pw) / 2, barY + 8,
                (fg << 24) | 0xAAAAAA, false);
    }
}
