package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Suddenly draws a near-black overlay for 0.5–1.5 seconds.
 * Simulates a monitor losing signal or a gamma spike.
 * Starts triggering after 3 minutes.
 */
@Environment(EnvType.CLIENT)
public class GammaFlickerEvent extends HorrorEvent {

    // Duration in ticks (half a second to 1.5 s)
    private int totalDuration;

    public GammaFlickerEvent() {
        super(3600); // 3 minutes
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(6000) == 0) {
            totalDuration = 10 + random.nextInt(20); // 0.5–1.5 s
            activate(totalDuration, 3600, 7200);     // 3–6 min cooldown
        }
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        if (!active) return;

        int w = screenW(client);
        int h = screenH(client);

        // Fast fade in, hold, fast fade out
        float f = calcAlpha(totalDuration, 4, 4);
        int a = (int)(f * 248);

        // Flicker: alternate between pure black and very dark blue
        boolean odd = (localTick % 4) < 2;
        int color = odd ? ((a << 24)) : ((a << 24) | 0x000008);

        context.fill(0, 0, w, h, color);
    }
}
