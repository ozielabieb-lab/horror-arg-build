package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * TV static noise overlaid on the screen.
 * Random white/grey pixels + horizontal scanlines.
 * Lasts 2–5 seconds. Starts after 5 minutes.
 */
@Environment(EnvType.CLIENT)
public class StaticOverlayEvent extends HorrorEvent {

    private int totalDuration;
    private static final int PIXEL_COUNT = 700;

    public StaticOverlayEvent() {
        super(6000); // 5 min
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(10000) == 0) {
            totalDuration = 40 + random.nextInt(60); // 2–5 s
            activate(totalDuration, 9600, 18000);    // 8–15 min cooldown
        }
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        if (!active) return;

        int w = screenW(client);
        int h = screenH(client);

        float f = calcAlpha(totalDuration, 5, 5);

        // ── Random static pixels ─────────────────────────────────────────────
        for (int i = 0; i < PIXEL_COUNT; i++) {
            int x    = random.nextInt(w);
            int y    = random.nextInt(h);
            int size = 1 + random.nextInt(4);
            int b    = 50 + random.nextInt(206);          // brightness
            int a    = (int)((80 + random.nextInt(175)) * f);
            context.fill(x, y, x + size, y + size, (a << 24) | (b << 16) | (b << 8) | b);
        }

        // ── Scanlines ────────────────────────────────────────────────────────
        int scanA = (int)(40 * f);
        for (int y = 0; y < h; y += 4) {
            context.fill(0, y, w, y + 1, scanA << 24);
        }

        // ── Overall dark tint ─────────────────────────────────────────────────
        context.fill(0, 0, w, h, (int)(0x18 * f) << 24);
    }
}
