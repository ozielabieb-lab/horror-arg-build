package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * A fake "You died!" screen appears for ~3 seconds.
 * The player hasn't actually died — the world keeps running.
 * The subtitle line is slightly off, hinting something is wrong.
 * Only fires once or twice. Starts after 30 minutes.
 */
@Environment(EnvType.CLIENT)
public class FakeDeathEvent extends HorrorEvent {

    private static final int MAX_FIRES = 2;
    private int fireCount    = 0;
    private int totalDuration;

    private static final String[] SUBTITLES = {
        "but you didn't.",
        "Score: NaN",
        "you can't die here.",
        "it won't let you.",
    };
    private String subtitle = "";

    public FakeDeathEvent() {
        super(36000); // 30 min
    }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (fireCount >= MAX_FIRES) return;
        if (client.player == null || client.player.isDead()) return;

        if (random.nextInt(36000) == 0) {
            subtitle      = SUBTITLES[random.nextInt(SUBTITLES.length)];
            totalDuration = 70; // ~3.5 s
            fireCount++;
            activate(totalDuration, 72000, 144000); // 60–120 min cooldown
        }
    }

    @Override
    public void render(DrawContext context, MinecraftClient client) {
        if (!active) return;

        int w = screenW(client);
        int h = screenH(client);

        float f     = calcAlpha(totalDuration, 10, 10);
        int redA    = (int)(f * 155);
        int textA   = (int)(f * 255);

        // ── Blood-red overlay ─────────────────────────────────────────────────
        context.fill(0, 0, w, h, (redA << 24) | 0x660000);

        if (textA <= 40) return;

        // ── "You died!" ───────────────────────────────────────────────────────
        context.getMatrices().push();
        context.getMatrices().scale(2f, 2f, 1f);
        String died = "You died!";
        int dw = client.textRenderer.getWidth(died);
        context.drawText(client.textRenderer, died,
                (w / 2 - dw) / 2, h / 4 / 2 - 8,
                (textA << 24) | 0xFFFFFF, true);
        context.getMatrices().pop();

        // ── Glitched subtitle ─────────────────────────────────────────────────
        int sw = client.textRenderer.getWidth(subtitle);
        context.drawText(client.textRenderer, subtitle,
                (w - sw) / 2, h / 2,
                (textA << 24) | 0xAAAAAA, false);

        // ── "Respawn" button outline (doesn't work — just decoration) ─────────
        if (localTick > 20) {
            int btnW = 80, btnH = 16;
            int btnX = (w - btnW) / 2;
            int btnY = h * 2 / 3;
            context.fill(btnX, btnY, btnX + btnW, btnY + btnH,
                    (int)(f * 100) << 24);
            context.fill(btnX, btnY, btnX + btnW, btnY + 1, (textA << 24) | 0x555555);
            context.fill(btnX, btnY + btnH - 1, btnX + btnW, btnY + btnH,
                    (textA << 24) | 0x555555);
            String btn = "Respawn";
            int bw = client.textRenderer.getWidth(btn);
            context.drawText(client.textRenderer, btn,
                    btnX + (btnW - bw) / 2, btnY + (btnH - 8) / 2,
                    (int)(f * 180) << 24 | 0xAAAAAA, false);
        }
    }
}
