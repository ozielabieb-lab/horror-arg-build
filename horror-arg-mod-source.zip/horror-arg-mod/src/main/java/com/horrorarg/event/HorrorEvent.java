package com.horrorarg.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/**
 * Base class for all client-side horror events.
 *
 * Lifecycle:
 *  1. tick() is called every client tick.
 *  2. When minGameTicks threshold passes AND cooldown is 0 → checkTrigger().
 *  3. Subclass calls activate(duration, cooldownMin, cooldownMax) to start the event.
 *  4. While active: onActiveTick() is called each tick, then render().
 *  5. When activeTicksRemaining reaches 0 → onDeactivate(), then cooldown begins.
 */
@Environment(EnvType.CLIENT)
public abstract class HorrorEvent {

    protected final Random random = new Random();

    protected boolean active              = false;
    protected int     activeTicksRemaining = 0;
    protected int     cooldownTicksRemaining = 0;
    protected int     localTick           = 0; // resets on each activation

    /** Game ticks that must pass before this event is allowed to fire at all. */
    protected final int minGameTicks;

    protected HorrorEvent(int minGameTicks) {
        this.minGameTicks = minGameTicks;
    }

    // ── Framework ─────────────────────────────────────────────────────────────

    public final void tick(MinecraftClient client, int gameTick) {
        if (client.world == null || client.player == null) return;
        if (gameTick < minGameTicks) return;

        if (active) {
            localTick++;
            activeTicksRemaining--;
            onActiveTick(client, gameTick);
            if (activeTicksRemaining <= 0) {
                active = false;
                onDeactivate(client);
            }
        } else if (cooldownTicksRemaining > 0) {
            cooldownTicksRemaining--;
        } else {
            checkTrigger(client, gameTick);
        }
    }

    /**
     * Called every tick while the event is NOT active and NOT on cooldown.
     * Subclasses roll the dice here and call activate() when they want to fire.
     */
    protected abstract void checkTrigger(MinecraftClient client, int gameTick);

    protected void activate(int durationTicks, int cooldownMin, int cooldownMax) {
        active                 = true;
        localTick              = 0;
        activeTicksRemaining   = durationTicks;
        cooldownTicksRemaining = cooldownMin + random.nextInt(Math.max(1, cooldownMax - cooldownMin));
    }

    /** Called once per tick while the event is active, BEFORE render(). */
    protected void onActiveTick(MinecraftClient client, int gameTick) {}

    /** Called once when the event's timer expires. */
    protected void onDeactivate(MinecraftClient client) {}

    /** Draw anything onto the HUD. Called every frame (even when inactive). */
    public abstract void render(DrawContext context, MinecraftClient client);

    // ── Helpers ───────────────────────────────────────────────────────────────

    protected int screenW(MinecraftClient c) { return c.getWindow().getScaledWidth();  }
    protected int screenH(MinecraftClient c) { return c.getWindow().getScaledHeight(); }

    /** Simple eased fade: 0→1 during firstTicks, 1 steady, 1→0 during lastTicks. */
    protected float calcAlpha(int total, int first, int last) {
        if (localTick < first) return (float) localTick / first;
        if (activeTicksRemaining < last) return (float) activeTicksRemaining / last;
        return 1f;
    }
}
