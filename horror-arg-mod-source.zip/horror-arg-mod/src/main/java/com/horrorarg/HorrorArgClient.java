package com.horrorarg;

import com.horrorarg.event.EventManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

@Environment(EnvType.CLIENT)
public class HorrorArgClient implements ClientModInitializer {

    public static EventManager eventManager;

    @Override
    public void onInitializeClient() {
        HorrorArgMod.LOGGER.info("Horror ARG | I've been waiting for you.");

        eventManager = new EventManager();

        // HUD overlay — rendered every frame on top of everything
        HudRenderCallback.EVENT.register((ctx, tickDelta) ->
                eventManager.renderHud(ctx, tickDelta));

        // Client tick — drives all event timers
        ClientTickEvents.END_CLIENT_TICK.register(client ->
                eventManager.tick(client));
    }
}
