package com.horrorarg;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Random;

public class HorrorArgMod implements ModInitializer {

    public static final String MOD_ID = "horrorarg";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // ── Global horror state ──────────────────────────────────────────────────
    public static volatile boolean mobsStaring   = true;
    public static volatile boolean mobsFrozen    = false;
    public static volatile float   overrideGamma = -1f; // -1 = not overriding

    // ── Freeze internals ─────────────────────────────────────────────────────
    private static final Random RANDOM = new Random();
    private static int freezeTicksLeft   = 0;
    private static int freezeCooldown    = 0;
    private static final int FREEZE_MIN_START   = 24000; // 20 min before first freeze
    private static final int FREEZE_COOLDOWN_MIN = 24000;
    private static final int FREEZE_COOLDOWN_RNG =  6000;

    private int serverTick = 0;

    @Override
    public void onInitialize() {
        LOGGER.info("Horror ARG | Something is already here...");
        ServerTickEvents.END_WORLD_TICK.register(this::onWorldTick);
    }

    // ─────────────────────────────────────────────────────────────────────────
    private void onWorldTick(ServerWorld world) {
        serverTick++;

        // ── Mob staring ───────────────────────────────────────────────────────
        if (mobsStaring) {
            for (ServerPlayerEntity player : world.getPlayers()) {
                List<PassiveEntity> passives = world.getEntitiesByClass(
                        PassiveEntity.class,
                        player.getBoundingBox().expand(64, 16, 64),
                        e -> !e.isDead() && !e.isRemoved()
                );
                for (PassiveEntity mob : passives) {
                    // 360 f/tick → mob snaps instantly to face player
                    mob.getLookControl().lookAt(player, 360f, 360f);
                }
            }
        }

        // ── Mob freeze ────────────────────────────────────────────────────────
        if (mobsFrozen) {
            freezeTicksLeft--;
            for (ServerPlayerEntity player : world.getPlayers()) {
                world.getEntitiesByClass(
                        PassiveEntity.class,
                        player.getBoundingBox().expand(64, 16, 64),
                        e -> !e.isDead()
                ).forEach(mob -> {
                    mob.getNavigation().stop();
                    mob.setVelocity(0, mob.getVelocity().y, 0);
                });
            }
            if (freezeTicksLeft <= 0) {
                mobsFrozen    = false;
                freezeCooldown = FREEZE_COOLDOWN_MIN + RANDOM.nextInt(FREEZE_COOLDOWN_RNG);
                LOGGER.info("Horror ARG | Mobs unfrozen.");
            }
        } else if (freezeCooldown > 0) {
            freezeCooldown--;
        } else if (serverTick > FREEZE_MIN_START && RANDOM.nextInt(15000) == 0) {
            triggerMobFreeze();
        }
    }

    // ── Public API ────────────────────────────────────────────────────────────
    public static void triggerMobFreeze() {
        mobsFrozen     = true;
        freezeTicksLeft = 160 + RANDOM.nextInt(240); // 8–20 seconds
        LOGGER.info("Horror ARG | Mobs frozen.");
    }

    /** Called from LivingEntityMixin when any PassiveEntity dies. */
    public static void onPassiveMobDied() {
        if (mobsStaring) {
            mobsStaring = false;
            LOGGER.info("Horror ARG | A passive mob was killed. They stopped staring.");
        }
    }
}
