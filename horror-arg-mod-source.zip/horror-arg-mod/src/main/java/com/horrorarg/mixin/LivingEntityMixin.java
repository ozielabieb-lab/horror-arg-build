package com.horrorarg.mixin;

import com.horrorarg.HorrorArgMod;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.passive.PassiveEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts LivingEntity.onDeath().
 * If the entity that died is a PassiveEntity (cow, sheep, chicken, pig, etc.)
 * and mobs were still staring, the staring flag is cleared — they all
 * immediately return to normal behaviour.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(method = "onDeath", at = @At("HEAD"))
    private void horrorArg_onDeath(DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity)(Object) this;
        if (self instanceof PassiveEntity) {
            HorrorArgMod.onPassiveMobDied();
        }
    }
}
