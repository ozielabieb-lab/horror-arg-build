package com.horrorarg.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reserved hook on GameRenderer for potential future effect overrides
 * (e.g. forced FOV changes, shader injection, post-processing).
 * Currently does nothing — kept here so the mixin class exists and
 * the config doesn't fail to load.
 */
@Environment(EnvType.CLIENT)
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void horrorArg_onRenderHead(float tickDelta, long startTime, boolean tick, CallbackInfo ci) {
        // Reserved for future use
    }
}
