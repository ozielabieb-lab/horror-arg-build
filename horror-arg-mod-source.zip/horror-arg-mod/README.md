# Horror ARG Mod — `horror-arg-1.0.0`

> **"You returned to your old world. Something is already here."**

A Minecraft Java Edition **Fabric** horror ARG mod designed for
**PojavLauncher on Android**. No entities added — pure events, overlays,
and world manipulation to create dread.

---

## Story premise

You load an old singleplayer world from years ago. The biomes, the builds,
the terrain — all exactly as you left it. But something never left.
It has been waiting. And it has noticed you came back.

---

## Events

| # | Event | When | Description |
|---|-------|------|-------------|
| 1 | **Mob Staring** | Immediately | Every cow, sheep, chicken, pig, and other passive mob in 64-block radius snaps its head to face you every tick. All four directions, no escape. **Kill one → they all immediately stop.** |
| 2 | **Vignette** | Always | A dark, pulsing frame permanently borders your screen. So subtle you might not notice for minutes. |
| 3 | **Gamma Flicker** | 3 min | The screen goes pitch black for 0.5–1.5 seconds, flickering. Like a monitor losing signal. |
| 4 | **Action Bar Glitch** | 3 min | Cryptic text appears above your hotbar: `"do not look back."` `"it's behind you."` `"i see you."` — in grey, as if it were a system message. |
| 5 | **Sound Anomaly** | 5 min | A ghast, enderman, warden, or phantom sound plays at full volume with no source. Wrong sound, wrong biome, wrong time. |
| 6 | **Static Overlay** | 5 min | TV static noise floods the screen for 2–5 seconds. Scanlines. Flickering pixels. |
| 7 | **Fake Chat** | 5 min | A chat message appears from `null`, `OldFriend2011`, `_ _ _`, or even **your own username**: *"do you remember this place?"* *"i've been here the whole time."* |
| 8 | **Cryptic Title** | 10 min | A large title + subtitle fade in: *"WORLD CORRUPTED — Attempting recovery..."* / *"OldFriend2011 has joined the game"* / *"it's in the world. it was always in the world."* |
| 9 | **Console Text** | 10 min | A fake green-on-black terminal window appears, scrolling fake error logs: `[ERROR] Unknown entity type: 'It'` / `[WARN] 1 passive entity refused to unload` |
| 10 | **Sky Darken** | 8 min | The entire sky goes black in seconds. Fake stars appear. A whisper: *"don't look up."* / *"the sky forgot the sun."* Lasts 6–12 seconds. |
| 11 | **Fake Loading** | 15 min | A black screen with "Saving world..." or "ERROR: world.dat missing" + a fake progress bar. The world keeps running underneath. |
| 12 | **Mob Freeze** | 20 min | All passive mobs near you stop moving completely. They still stare. 8–20 seconds of silence. Then they unfreeze all at once. |
| 13 | **Fake Death** | 30 min | *"You died!"* appears in full red. The game is still running. The subtitle reads *"but you didn't."* / *"it won't let you."* Fires max twice. |

---

## Requirements

| Dependency | Version |
|------------|---------|
| Minecraft Java | **1.20.1** |
| Fabric Loader | **0.15.7** |
| Fabric API | **0.92.2+1.20.1** |
| Java JDK (to compile) | **17** |

---

## How to compile

You need **Java 17 JDK** installed on a PC/Mac/Linux machine.

```bash
# 1. Clone or extract this project folder
cd horror-arg-mod

# 2. Make the Gradle wrapper executable (Linux/Mac)
chmod +x gradlew

# 3. Build
./gradlew build          # Linux / Mac
gradlew.bat build        # Windows

# 4. Find the JAR
# build/libs/horror-arg-1.0.0.jar
```

Compilation downloads Minecraft assets (~500 MB) on first run.
This requires a working internet connection.

---

## Installing on PojavLauncher (Android)

1. **Install PojavLauncher** and log in with your Microsoft account.
2. In PojavLauncher settings, install **Fabric Loader 0.15.7** for **Minecraft 1.20.1**.
3. Launch 1.20.1+Fabric once so the mods folder is created.
4. Copy these three files to `/sdcard/Android/data/net.kdt.pojavlaunch/files/.minecraft/mods/`:
   - `horror-arg-1.0.0.jar` (this mod)
   - `fabric-api-0.92.2+1.20.1.jar` (download from [modrinth.com](https://modrinth.com/mod/fabric-api))
5. Launch the game. Load any **singleplayer** world.

> **Note:** Events use client ticks (`≈20/s`). Timing is based on how long
> you've been in the world, not real-world time.

---

## Frequently asked questions

**Q: Can I add more events?**  
A: Yes. Create a new class that extends `HorrorEvent`, implement
`checkTrigger()` and `render()`, then add it to `EventManager`'s list.

**Q: Can I change when events trigger?**  
A: Each event constructor takes a `minGameTicks` (ticks before it can fire).
20 ticks = 1 second. Edit the constructor argument.

**Q: The mobs aren't staring.**  
A: Make sure you're in a singleplayer world with passive mobs nearby. The
staring is server-side and only applies to mobs within 64 blocks.

**Q: Does this work in multiplayer?**  
A: Partially. Client events (overlays, sounds, chat) work on any server.
Mob staring and mob freeze only work in singleplayer (integrated server).

---

## File structure

```
src/main/java/com/horrorarg/
├── HorrorArgMod.java          ← Server init: mob staring + freeze
├── HorrorArgClient.java       ← Client init: event manager + HUD
├── event/
│   ├── HorrorEvent.java       ← Abstract base class
│   ├── EventManager.java      ← Coordinates all events
│   └── impl/
│       ├── VignetteEvent.java
│       ├── GammaFlickerEvent.java
│       ├── ActionBarGlitchEvent.java
│       ├── SoundAnomalyEvent.java
│       ├── StaticOverlayEvent.java
│       ├── FakeChatEvent.java
│       ├── CrypticTitleEvent.java
│       ├── ConsoleTextEvent.java
│       ├── SkyDarkenEvent.java
│       ├── FakeLoadingEvent.java
│       ├── MobFreezeClientEvent.java
│       └── FakeDeathEvent.java
└── mixin/
    ├── LivingEntityMixin.java  ← Detects passive mob death
    └── GameRendererMixin.java  ← Reserved hook
```

---

*This world was never empty.*
