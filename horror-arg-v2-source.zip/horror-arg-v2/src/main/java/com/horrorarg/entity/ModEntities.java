package com.horrorarg.entity;

import com.horrorarg.HorrorArgMod;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static EntityType<ShadowEntity> SHADOW;

    public static void register() {
        SHADOW = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(HorrorArgMod.MOD_ID, "shadow"),
            EntityType.Builder.<ShadowEntity>create(ShadowEntity::new, SpawnGroup.MISC)
                    .setDimensions(0.6f, 1.8f)
                    .maxTrackingRange(128)
                    .build()
        );
    }
}