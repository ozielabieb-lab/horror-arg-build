package com.horrorarg.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.World;

public class ShadowEntity extends MobEntity {

    private int existTicks = 0;
    public static final int    MAX_TICKS = 1200;
    public static final double FLEE_DSQ  = 12.0 * 12.0;

    public ShadowEntity(EntityType<? extends ShadowEntity> type, World world) {
        super(type, world);
        this.setInvulnerable(true);
        this.setSilent(true);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 9999.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0);
    }

    @Override protected void initGoals() {}

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) return;
        existTicks++;

        PlayerEntity player = getWorld().getClosestPlayer(this, 128);
        if (player != null) {
            double dx = player.getX() - getX();
            double dz = player.getZ() - getZ();
            float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
            setYaw(yaw); setHeadYaw(yaw); setBodyYaw(yaw);
            if (player.squaredDistanceTo(this) < FLEE_DSQ) { discard(); return; }
        }

        getNavigation().stop();
        setVelocity(0, getVelocity().y, 0);
        if (existTicks > MAX_TICKS) discard();
    }

    @Override public boolean damage(DamageSource source, float amount) { return false; }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        existTicks = nbt.getInt("ExistTicks");
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("ExistTicks", existTicks);
    }
}
