package com.horrorarg.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class ShadowEntityRenderer
        extends MobEntityRenderer<ShadowEntity, PlayerEntityModel<ShadowEntity>> {

    private static final Identifier TEXTURE =
            new Identifier("horrorarg", "textures/entity/shadow.png");

    public ShadowEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0f);
    }

    @Override
    public Identifier getTexture(ShadowEntity entity) { return TEXTURE; }
}
