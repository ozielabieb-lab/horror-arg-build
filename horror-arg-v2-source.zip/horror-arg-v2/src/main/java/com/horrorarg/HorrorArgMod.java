package com.horrorarg;

import com.horrorarg.entity.ModEntities;
import com.horrorarg.entity.ShadowEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;

public class HorrorArgMod implements ModInitializer {

    public static final String MOD_ID = "horrorarg";
    public static final Logger LOGGER  = LoggerFactory.getLogger(MOD_ID);

    public static volatile boolean mobsStaring = true;
    public static volatile boolean mobsFrozen  = false;

    private static final Random RANDOM = new Random();
    private static int freezeLeft      = 0;
    private static int freezeCooldown  = 0;
    private static int shadowCooldown  = 0;

    private static final int FREEZE_START   = 24000;
    private static final int FREEZE_CD_MIN  = 24000;
    private static final int FREEZE_CD_RNG  =  6000;
    private static final int SHADOW_START   = 18000;
    private static final int SHADOW_CD_MIN  = 18000;
    private static final int SHADOW_CD_RNG  =  9000;

    private int tick = 0;

    @Override
    public void onInitialize() {
        LOGGER.info("Horror ARG | Something is already here...");
        ModEntities.register();
        FabricDefaultAttributeRegistry.register(ModEntities.SHADOW, ShadowEntity.createAttributes());
        ServerTickEvents.END_WORLD_TICK.register(this::onWorldTick);
    }

    private void onWorldTick(ServerWorld world) {
        tick++;

        // ── Mob freeze ────────────────────────────────────────────────────────
        if (mobsFrozen) {
            freezeLeft--;
            for (ServerPlayerEntity player : world.getPlayers()) {
                world.getEntitiesByClass(PassiveEntity.class,
                        player.getBoundingBox().expand(64, 16, 64),
                        e -> !e.isDead()
                ).forEach(mob -> {
                    mob.getNavigation().stop();
                    mob.setVelocity(0, mob.getVelocity().y, 0);
                });
            }
            if (freezeLeft <= 0) {
                mobsFrozen    = false;
                freezeCooldown = FREEZE_CD_MIN + RANDOM.nextInt(FREEZE_CD_RNG);
            }
        } else if (freezeCooldown > 0) {
            freezeCooldown--;
        } else if (tick > FREEZE_START && RANDOM.nextInt(15000) == 0) {
            mobsFrozen = true;
            freezeLeft = 160 + RANDOM.nextInt(240);
        }

        // ── Shadow entity spawn ───────────────────────────────────────────────
        if (shadowCooldown > 0) {
            shadowCooldown--;
        } else if (tick > SHADOW_START && RANDOM.nextInt(18000) == 0) {
            spawnShadow(world);
        }
    }

    private void spawnShadow(ServerWorld world) {
        for (ServerPlayerEntity player : world.getPlayers()) {
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double dist  = 35 + RANDOM.nextDouble() * 20;
            double x = player.getX() + Math.cos(angle) * dist;
            double z = player.getZ() + Math.sin(angle) * dist;

            ShadowEntity shadow = new ShadowEntity(ModEntities.SHADOW, world);
            shadow.setPosition(x, player.getY(), z);
            world.spawnEntity(shadow);
            shadowCooldown = SHADOW_CD_MIN + RANDOM.nextInt(SHADOW_CD_RNG);
            LOGGER.info("Horror ARG | Shadow spawned.");
            break;
        }
    }

    public static void onPassiveMobDied() {
        if (mobsStaring) {
            mobsStaring = false;
            LOGGER.info("Horror ARG | Staring stopped.");
        }
    }
}
