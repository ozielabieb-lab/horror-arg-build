package com.horrorarg.mixin;

import com.horrorarg.HorrorArgMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MobEntity.class)
public abstract class MobEntityStaringMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void horrorArg_forceStare(CallbackInfo ci) {
        MobEntity self = (MobEntity)(Object) this;
        if (!(self instanceof PassiveEntity)) return;
        if (!HorrorArgMod.mobsStaring) return;
        if (self.getWorld().isClient()) return;

        PlayerEntity player = self.getWorld().getClosestPlayer(self, 64);
        if (player == null) return;

        double dx = player.getX() - self.getX();
        double dz = player.getZ() - self.getZ();
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx))) - 90f;

        // Akses via method public di 1.20.4
        self.setYaw(yaw);
        self.setHeadYaw(yaw);
        self.setBodyYaw(yaw);
        self.prevYaw     = yaw;
        self.prevHeadYaw = yaw;
    }
}