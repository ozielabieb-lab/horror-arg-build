package com.horrorarg.mixin;

import com.horrorarg.HorrorArgMod;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Inject di akhir tick mob — setelah semua AI goals selesai.
 * Paksa rotasi kepala langsung ke player setiap frame.
 * Tidak bisa di-override sampai tick berikutnya.
 */
@Mixin(MobEntity.class)
public abstract class MobEntityStaringMixin {

    @Shadow public float headYaw;
    @Shadow public float prevHeadYaw;
    @Shadow public float bodyYaw;
    @Shadow public float prevBodyYaw;

    @Inject(method = "tick", at = @At("TAIL"))
    private void horrorArg_forceStare(CallbackInfo ci) {
        MobEntity self = (MobEntity)(Object) this;
        if (!(self instanceof PassiveEntity)) return;
        if (!HorrorArgMod.mobsStaring) return;
        if (self.getWorld().isClient()) return;

        PlayerEntity player = self.getWorld().getClosestPlayer(self, 64);
        if (player == null) return;

        double dx = player.getX() - self.getX();
        double dz = player.getZ() - self.getZ();
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx))) - 90f;

        this.headYaw     = yaw;
        this.prevHeadYaw = yaw;
        this.bodyYaw     = yaw;
        this.prevBodyYaw = yaw;
    }
}
