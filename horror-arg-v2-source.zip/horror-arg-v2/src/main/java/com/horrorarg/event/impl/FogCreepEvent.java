package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Kabut abu-abu pelan-pelan merayap masuk dari semua tepi layar.
 * Di puncaknya dunia terasa seperti hilang dalam keabuan.
 * Lalu perlahan surut.
 */
@Environment(EnvType.CLIENT)
public class FogCreepEvent extends HorrorEvent {

    private int totalDuration;

    public FogCreepEvent() { super(12000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(16000) == 0) {
            totalDuration = 200 + random.nextInt(200);
            activate(totalDuration, 14000, 24000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);

        // Puncak kabut di tengah durasi
        float f = calcAlpha(totalDuration, totalDuration/3, totalDuration/3);
        int fogA = (int)(f * 170);
        if (fogA <= 0) return;

        int fogSize = (int)(f * Math.min(w, h) * 0.48f);
        if (fogSize <= 0) return;

        int outer = (Math.min(255, fogA + 60) << 24) | 0xCCCCCC;
        int inner = 0x00CCCCCC;

        // Kabut dari 4 arah
        ctx.fillGradient(0,            0,            fogSize,       h,       outer, inner);
        ctx.fillGradient(w - fogSize,  0,            w,             h,       inner, outer);
        ctx.fillGradient(0,            0,            w,             fogSize, outer, inner);
        ctx.fillGradient(0,            h - fogSize,  w,             h,       inner, outer);

        // Haze tipis di tengah
        ctx.fill(0, 0, w, h, (fogA / 6) << 24 | 0xCCCCCC);
    }
}
