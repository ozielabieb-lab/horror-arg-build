package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class FakeLoadingEvent extends HorrorEvent {
    private static final String[] TEXTS = {
        "Saving world","Loading terrain","Generating world","Building chunks",
        "Scanning entities","Verifying world data","Recovering lost data",
        "Loading: OldWorld_2011 (1 of 1)","Preparing spawn area: 100%",
        "ERROR: world.dat missing","Restoring from backup","Resolving corrupted chunks"
    };
    private String text = "";
    private int dots = 0, totalDuration;
    public FakeLoadingEvent() { super(18000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(20000) == 0) {
            text = TEXTS[random.nextInt(TEXTS.length)];
            dots = 0; totalDuration = 80 + random.nextInt(60);
            activate(totalDuration, 18000, 30000);
        }
    }

    @Override protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (localTick % 10 == 0) dots = (dots+1) % 4;
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 8, 8);
        int bg = (int)(f*240), fg = (int)(f*255);
        ctx.fill(0, 0, w, h, bg<<24);
        String display = text + ".".repeat(dots);
        int tw = client.textRenderer.getWidth(display);
        ctx.drawText(client.textRenderer, display, (w-tw)/2, h/2-10, (fg<<24)|0xFFFFFF, false);
        int barW = w/3, barX = (w-barW)/2, barY = h/2+10;
        float progress = (localTick % 60) / 60f;
        ctx.fill(barX, barY, barX+barW, barY+4, (fg<<24)|0x333333);
        ctx.fill(barX, barY, barX+(int)(barW*progress), barY+4, (fg<<24)|0xFFFFFF);
        String pct = (int)(progress*100) + "%";
        int pw = client.textRenderer.getWidth(pct);
        ctx.drawText(client.textRenderer, pct, (w-pw)/2, barY+8, (fg<<24)|0xAAAAAA, false);
    }
}
