package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class VignetteEvent extends HorrorEvent {
    private final long startTime = System.currentTimeMillis();

    public VignetteEvent() {
        super(0);
        active = true;
        activeTicksRemaining = Integer.MAX_VALUE;
    }

    @Override protected void checkTrigger(MinecraftClient c, int t) {}

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        int w = screenW(client), h = screenH(client);
        double elapsed = (System.currentTimeMillis() - startTime) / 1000.0;
        float pulse = (float)(0.675 + 0.125 * Math.sin(elapsed * 0.4));
        int a = (int)(pulse * 200);
        int vigW = w / 5, vigH = h / 5;

        ctx.fillGradient(0, 0, w, vigH, a << 24, 0x00000000);
        ctx.fillGradient(0, h - vigH, w, h, 0x00000000, a << 24);
        ctx.fill(0, 0, vigW / 2, h, a << 24);
        ctx.fill(vigW / 2, 0, vigW, h, (a/2) << 24);
        ctx.fill(w - vigW, 0, w - vigW/2, h, (a/2) << 24);
        ctx.fill(w - vigW/2, 0, w, h, a << 24);
    }
}
