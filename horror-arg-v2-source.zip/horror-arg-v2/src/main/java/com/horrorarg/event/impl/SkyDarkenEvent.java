package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class SkyDarkenEvent extends HorrorEvent {
    private int totalDuration;
    private final int[] starX = new int[80], starY = new int[80];
    private final Random starRng = new Random(0xDEADBEEFL);
    private static final String[] WHISPERS = {
        "why is it dark?","the sky forgot the sun.",
        "don\'t look up.","they\'re watching from the dark.",
        "it remembers when this was daytime."
    };
    private String whisper = "";

    public SkyDarkenEvent() { super(9600); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(18000) == 0) {
            totalDuration = 120 + random.nextInt(120);
            whisper = WHISPERS[random.nextInt(WHISPERS.length)];
            starRng.setSeed(gameTick);
            int w = screenW(client), h = screenH(client);
            for (int i = 0; i < starX.length; i++) {
                starX[i] = starRng.nextInt(Math.max(1,w));
                starY[i] = starRng.nextInt(Math.max(1,h));
            }
            activate(totalDuration, 12000, 24000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 12, 12);
        int darkA = (int)(f * 225);
        ctx.fill(0, 0, w, h, (darkA<<24)|0x000008);
        if (darkA > 80)
            for (int i = 0; i < starX.length; i++) {
                double twinkle = Math.sin(localTick * 0.12 + i * 1.7);
                int sa = (int)((darkA-80)*0.6*(0.5+0.5*twinkle));
                if (sa > 0) ctx.fill(starX[i], starY[i], starX[i]+1, starY[i]+1, (sa<<24)|0xFFFFFF);
            }
        if (darkA > 140 && localTick > 18 && activeTicksRemaining > 18) {
            int tA = Math.min(255, (darkA-140)*4);
            int tw = client.textRenderer.getWidth(whisper);
            ctx.drawText(client.textRenderer, whisper, (w-tw)/2, h/2, (tA<<24)|0x444444, false);
        }
    }
}
