package com.horrorarg.event.impl;

import com.horrorarg.HorrorArgMod;
import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class MobFreezeClientEvent extends HorrorEvent {
    private int blinkTick = 0;

    public MobFreezeClientEvent() {
        super(0);
        active = true; activeTicksRemaining = Integer.MAX_VALUE;
    }

    @Override protected void checkTrigger(MinecraftClient c, int t) {}
    @Override protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (HorrorArgMod.mobsFrozen) blinkTick++; else blinkTick = 0;
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!HorrorArgMod.mobsFrozen) return;
        int w = screenW(client), h = screenH(client);
        ctx.fill(0, 0, w, h, 0x0C002244);
        if (blinkTick % 40 < 20) {
            String dots = "...";
            int dw = client.textRenderer.getWidth(dots);
            ctx.drawText(client.textRenderer, dots, (w-dw)/2, h/3, 0x66AACCFF, false);
        }
    }
}
