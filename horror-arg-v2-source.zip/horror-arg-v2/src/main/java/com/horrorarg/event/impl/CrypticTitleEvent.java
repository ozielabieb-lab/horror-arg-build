package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class CrypticTitleEvent extends HorrorEvent {
    private static final String[][] PAIRS = {
        {"...", "i\'m still here"},
        {"do you remember?", ""},
        {"ERROR", "Entity_Unknown not found"},
        {"", "why did you come back?"},
        {"it sees you", ""},
        {"WORLD CORRUPTED", "Attempting recovery..."},
        {"OldFriend2011", "has joined the game"},
        {"hello", "i missed you so much"},
        {"stop.", "please just stop."},
        {"MEMORY LEAK", "core_world.dat damaged"},
        {"you left.", "but i didn\'t."},
        {"\u2588\u2588\u2588\u2588", "something is wrong"},
        {"it\'s in the world.", "it was always in the world."}
    };
    private String title = "", subtitle = "";
    private int totalDuration;

    public CrypticTitleEvent() { super(12000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(14000) == 0) {
            String[] pair = PAIRS[random.nextInt(PAIRS.length)];
            title = pair[0]; subtitle = pair[1];
            if (client.player != null && random.nextInt(4) == 0) {
                String name = client.player.getName().getString();
                title = title.replace("you", name);
                subtitle = subtitle.replace("you", name);
            }
            totalDuration = 80;
            activate(totalDuration, 12000, 24000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 12, 12);
        int textA = (int)(f * 255), shadowA = (int)(f * 200);
        if (textA <= 0) return;

        if (!title.isEmpty()) {
            ctx.getMatrices().push();
            ctx.getMatrices().scale(2f, 2f, 1f);
            int tw = client.textRenderer.getWidth(title);
            ctx.drawText(client.textRenderer, title, (w/2 - tw)/2, h/4/2 - 10, (textA<<24)|0xFFFFFF, true);
            ctx.getMatrices().pop();
        }
        if (!subtitle.isEmpty()) {
            int sw = client.textRenderer.getWidth(subtitle);
            ctx.drawText(client.textRenderer, subtitle, (w-sw)/2, h/2, (shadowA<<24)|0xCCCCCC, true);
        }
    }
}
