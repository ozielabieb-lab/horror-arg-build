package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class StaticOverlayEvent extends HorrorEvent {
    private int totalDuration;
    public StaticOverlayEvent() { super(6000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(10000) == 0) {
            totalDuration = 40 + random.nextInt(60);
            activate(totalDuration, 9600, 18000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 5, 5);
        for (int i = 0; i < 700; i++) {
            int x = random.nextInt(w), y = random.nextInt(h);
            int size = 1 + random.nextInt(4);
            int b = 50 + random.nextInt(206);
            int a = (int)((80 + random.nextInt(175)) * f);
            ctx.fill(x, y, x + size, y + size, (a << 24) | (b << 16) | (b << 8) | b);
        }
        int scanA = (int)(40 * f);
        for (int y = 0; y < h; y += 4) ctx.fill(0, y, w, y + 1, scanA << 24);
        ctx.fill(0, 0, w, h, (int)(0x18 * f) << 24);
    }
}
