package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class ConsoleTextEvent extends HorrorEvent {
    private static final String[] POOL = {
        "[ERROR] Entity \'unknown\' spawned at undefined coordinates",
        "[WARN]  Chunk data corrupted: 0x4F3A11B2",
        "[INFO]  Player connected: OldFriend2011 (last seen: never)",
        "[ERROR] NullPointerException @ world.tick() : line 0x0000",
        "[WARN]  Memory leak in entity handler -- leak size: unknown",
        "[INFO]  World seed: \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588",
        "[ERROR] Failed to load save: file may be corrupted",
        "[WARN]  Unknown entity type encountered: \'It\'",
        "[INFO]  Loading entity AI... FAILED.",
        "[ERROR] StackOverflow: lookAt().lookAt().lookAt()...",
        "[WARN]  Unexpected audio source detected near spawn",
        "[INFO]  Player data: loaded (last modified: 2011-03-??)",
        "[ERROR] Block state invalid @ world spawn",
        "[WARN]  1 passive entity refused to unload from chunk",
        "[INFO]  Server tick took 99999 ms (expected: 50 ms)",
        "[ERROR] Cannot locate player save data",
        "[WARN]  This world should not exist.",
        "[INFO]  Restore attempt failed. Skipping.",
        "[ERROR] Something is still reading the world.",
        "[WARN]  Gaze direction locked on PlayerEntity"
    };

    private final List<String> lines = new ArrayList<>();
    private int totalDuration;
    public ConsoleTextEvent() { super(12000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(14000) == 0) {
            lines.clear();
            totalDuration = 200 + random.nextInt(100);
            activate(totalDuration, 9600, 18000);
        }
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (localTick % 12 == 0 && lines.size() < 14) {
            String line = POOL[random.nextInt(POOL.length)];
            if (client.player != null && random.nextInt(4) == 0)
                line = line.replace("PlayerEntity", client.player.getName().getString());
            lines.add(line);
        }
    }

    @Override protected void onDeactivate(MinecraftClient client) { lines.clear(); }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active || lines.isEmpty()) return;
        float f = calcAlpha(totalDuration, 8, 8);
        int bg = (int)(f*210), fg = (int)(f*255);
        int lineH = client.textRenderer.fontHeight + 2;
        int maxW = screenW(client)*7/12;
        int panelH = lines.size()*lineH + 24;
        int panelX = 12, panelY = (screenH(client)-panelH)/2;

        ctx.fill(panelX-4, panelY-4, panelX+maxW+8, panelY+panelH+4, (bg<<24)|0x000000);
        ctx.fill(panelX-4, panelY-5, panelX+maxW+8, panelY-4, (fg<<24)|0x00CC00);
        ctx.drawText(client.textRenderer, ">> SYSTEM LOG <<", panelX, panelY, (fg<<24)|0x00FF00, false);

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            int y = panelY + (i+1)*lineH + 6;
            int color = line.contains("[ERROR]") ? (fg<<24)|0xFF4444
                      : line.contains("[WARN]")  ? (fg<<24)|0xFFAA00
                      : (fg<<24)|0x88FF88;
            while (client.textRenderer.getWidth(line) > maxW && line.length() > 6)
                line = line.substring(0, line.length()-1);
            ctx.drawText(client.textRenderer, line, panelX, y, color, false);
        }
        if (localTick % 20 < 10) {
            int cy = panelY + (lines.size()+1)*lineH + 6;
            ctx.drawText(client.textRenderer, "\u2588", panelX, cy, (fg<<24)|0x00FF00, false);
        }
    }
}
