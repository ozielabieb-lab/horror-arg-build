package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Efek VHS:
 *  - PASIF: scanline tipis selalu muncul (seperti layar CRT lama).
 *  - AKTIF: setiap beberapa menit, glitch meledak:
 *      chromatic aberration (merah kiri, biru kanan),
 *      horizontal noise band, tracking error bar,
 *      dan desaturasi abu-abu sebentar.
 */
@Environment(EnvType.CLIENT)
public class VhsGlitchEvent extends HorrorEvent {

    private boolean glitching     = false;
    private int     glitchTick    = 0;
    private int     glitchDuration = 0;
    private int     glitchCooldown = 0;

    public VhsGlitchEvent() {
        super(0);
        active               = true;
        activeTicksRemaining = Integer.MAX_VALUE;
    }

    @Override protected void checkTrigger(MinecraftClient c, int t) {}

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (glitching) {
            glitchTick++;
            if (glitchTick >= glitchDuration) {
                glitching     = false;
                glitchCooldown = 7200 + random.nextInt(9000); // 6-12 menit
            }
        } else if (glitchCooldown > 0) {
            glitchCooldown--;
        } else if (gameTick > 3600 && random.nextInt(9000) == 0) {
            glitching      = true;
            glitchTick     = 0;
            glitchDuration = 30 + random.nextInt(70); // 1.5-5 detik
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        int w = screenW(client), h = screenH(client);

        // ── PASIF: scanline sangat tipis (selalu ada) ─────────────────────────
        for (int y = 0; y < h; y += 2)
            ctx.fill(0, y, w, y + 1, 0x0A000000); // ~4% hitam

        if (!glitching) return;

        // Hitung fade in/out
        float f;
        if (glitchTick < 5)                          f = glitchTick / 5f;
        else if (glitchDuration - glitchTick < 5)    f = (glitchDuration - glitchTick) / 5f;
        else                                          f = 1f;

        // ── Scanline lebih kuat ───────────────────────────────────────────────
        for (int y = 0; y < h; y += 2)
            ctx.fill(0, y, w, y + 1, (int)(0x18 * f) << 24);

        // ── Chromatic aberration: merah geser kiri, biru geser kanan ─────────
        int ca = (int)(0x16 * f);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(-3, 0, 0);
        ctx.fill(-3, 0, w + 3, h, (ca << 24) | 0xFF0000);
        ctx.getMatrices().pop();

        ctx.getMatrices().push();
        ctx.getMatrices().translate(3, 0, 0);
        ctx.fill(-3, 0, w + 3, h, (ca << 24) | 0x0000FF);
        ctx.getMatrices().pop();

        // ── Horizontal noise band acak ────────────────────────────────────────
        int bands = 2 + random.nextInt(5);
        for (int i = 0; i < bands; i++) {
            int gy = random.nextInt(h);
            int gh = 1 + random.nextInt(3);
            int gb = 100 + random.nextInt(155);
            int ga = (int)((30 + random.nextInt(90)) * f);
            ctx.fill(0, gy, w, gy + gh, (ga << 24) | (gb << 16) | (gb << 8) | gb);
        }

        // ── Tracking error bar (setiap 20 tick) ──────────────────────────────
        if (glitchTick % 20 < 4) {
            int ty = random.nextInt(h);
            ctx.fill(0, ty, w, ty + 6, (int)(0x2A * f) << 24 | 0xFFFFFF);
        }

        // ── Tint abu-abu (desaturasi) ─────────────────────────────────────────
        ctx.fill(0, 0, w, h, (int)(0x0E * f) << 24 | 0x888888);
    }
}
