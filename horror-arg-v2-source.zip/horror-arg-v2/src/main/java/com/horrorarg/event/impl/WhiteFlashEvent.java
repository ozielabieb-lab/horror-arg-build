package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Kilat putih menyilaukan selama 2-5 frame.
 * Seperti kamera flash atau overexposure sesaat.
 * Sangat mengejutkan.
 */
@Environment(EnvType.CLIENT)
public class WhiteFlashEvent extends HorrorEvent {

    private int totalDuration;

    public WhiteFlashEvent() { super(6000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(9000) == 0) {
            totalDuration = 2 + random.nextInt(4);
            activate(totalDuration, 6000, 14000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        // Cepat terang, cepat memudar
        float f = calcAlpha(totalDuration, 1, 2);
        int a = (int)(f * 245);
        ctx.fill(0, 0, w, h, (a << 24) | 0xFFFFFF);
    }
}
