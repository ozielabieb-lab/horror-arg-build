package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

@Environment(EnvType.CLIENT)
public class BreathingEvent extends HorrorEvent {
    private int totalDuration;
    public BreathingEvent() { super(8000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(10000) == 0) {
            totalDuration = 120 + random.nextInt(60);
            activate(totalDuration, 9000, 18000);
            client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_GHAST_AMBIENT, 0.12f, 0.28f));
        }
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (localTick == totalDuration / 2)
            client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_GHAST_AMBIENT, 0.15f, 0.22f));
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        double phase = Math.sin(localTick * 0.12);
        float intensity = (float)(0.4 + 0.6 * Math.max(0, phase));
        float f = calcAlpha(totalDuration, 15, 15);
        int a = (int)(f * intensity * 55);
        ctx.fill(0, 0, w, h, (a << 24) | 0x440000);
        int ea = Math.min(255, a * 2);
        ctx.fillGradient(0, 0, w/4, h, (ea << 24) | 0x220000, 0x00000000);
        ctx.fillGradient(w*3/4, 0, w, h, 0x00000000, (ea << 24) | 0x220000);
        ctx.fillGradient(0, h*3/4, w, h, 0x00000000, (ea << 24) | 0x220000);
    }
}
