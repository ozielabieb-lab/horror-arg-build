package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class FakeDeathEvent extends HorrorEvent {
    private static final int MAX_FIRES = 2;
    private int fireCount = 0, totalDuration;
    private static final String[] SUBTITLES = {
        "but you didn\'t.","Score: NaN","you can\'t die here.","it won\'t let you."
    };
    private String subtitle = "";
    public FakeDeathEvent() { super(36000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (fireCount >= MAX_FIRES) return;
        if (client.player == null || client.player.isDead()) return;
        if (random.nextInt(36000) == 0) {
            subtitle = SUBTITLES[random.nextInt(SUBTITLES.length)];
            totalDuration = 70; fireCount++;
            activate(totalDuration, 72000, 144000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 10, 10);
        int redA = (int)(f*155), textA = (int)(f*255);
        ctx.fill(0, 0, w, h, (redA<<24)|0x660000);
        if (textA <= 40) return;
        ctx.getMatrices().push();
        ctx.getMatrices().scale(2f, 2f, 1f);
        String died = "You died!";
        int dw = client.textRenderer.getWidth(died);
        ctx.drawText(client.textRenderer, died, (w/2-dw)/2, h/4/2-8, (textA<<24)|0xFFFFFF, true);
        ctx.getMatrices().pop();
        int sw = client.textRenderer.getWidth(subtitle);
        ctx.drawText(client.textRenderer, subtitle, (w-sw)/2, h/2, (textA<<24)|0xAAAAAA, false);
    }
}
