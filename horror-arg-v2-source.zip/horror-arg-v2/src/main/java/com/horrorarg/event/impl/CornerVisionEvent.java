package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class CornerVisionEvent extends HorrorEvent {
    private int cx, cy, totalDuration;
    public CornerVisionEvent() { super(6000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(7000) == 0) {
            int w = screenW(client), h = screenH(client);
            cx = random.nextBoolean() ? 8 : w - 28;
            cy = random.nextBoolean() ? 8 : h - 45;
            totalDuration = 3 + random.nextInt(6);
            activate(totalDuration, 5000, 10000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        float f = calcAlpha(totalDuration, 1, 1);
        int a = (int)(f * 210);
        // Kepala
        ctx.fill(cx+5, cy,    cx+15, cy+8,  a<<24);
        // Badan
        ctx.fill(cx+3, cy+8,  cx+17, cy+24, a<<24);
        // Lengan kiri
        ctx.fill(cx,   cy+8,  cx+3,  cy+22, a<<24);
        // Lengan kanan
        ctx.fill(cx+17,cy+8,  cx+20, cy+22, a<<24);
        // Kaki kiri
        ctx.fill(cx+3, cy+24, cx+9,  cy+42, a<<24);
        // Kaki kanan
        ctx.fill(cx+11,cy+24, cx+17, cy+42, a<<24);
        // Mata merah
        ctx.fill(cx+6, cy+2,  cx+8,  cy+4,  (a<<24)|0xCC0000);
        ctx.fill(cx+12,cy+2,  cx+14, cy+4,  (a<<24)|0xCC0000);
    }
}
