package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

@Environment(EnvType.CLIENT)
public class FootstepBehindEvent extends HorrorEvent {
    public FootstepBehindEvent() { super(6000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(7000) == 0 && client.player != null) {
            int steps = 3 + random.nextInt(3);
            activate(steps * 10, 6000, 12000);
        }
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (localTick % 10 == 1) {
            float pitch = 0.75f + random.nextFloat() * 0.3f;
            client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.BLOCK_STONE_STEP, pitch, 0.5f));
        }
    }
    @Override public void render(DrawContext ctx, MinecraftClient client) {}
}
