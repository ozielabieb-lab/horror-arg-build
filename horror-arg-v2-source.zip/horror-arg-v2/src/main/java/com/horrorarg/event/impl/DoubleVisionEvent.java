package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Chromatic aberration + double vision.
 * Lapisan merah dan biru terpisah — seperti layar yang tidak sinkron.
 * Semakin lama, semakin melebar, semakin pusing.
 */
@Environment(EnvType.CLIENT)
public class DoubleVisionEvent extends HorrorEvent {

    private int totalDuration, splitX, splitY;

    public DoubleVisionEvent() { super(10000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(14000) == 0) {
            totalDuration = 60 + random.nextInt(60);
            splitX = 4 + random.nextInt(5);
            splitY = random.nextInt(3) - 1;
            activate(totalDuration, 10000, 20000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);

        float f = calcAlpha(totalDuration, 10, 10);
        // Jarak split berdenyut perlahan
        double osc = 1.0 + 0.35 * Math.sin(localTick * 0.13);
        int dx = (int)(splitX * osc);
        int dy = (int)(splitY * osc);

        int red  = (int)(f * 0x1C);
        int blue = (int)(f * 0x1C);

        // Lapisan merah geser kiri/atas
        ctx.getMatrices().push();
        ctx.getMatrices().translate(-dx, -dy, 0);
        ctx.fill(-dx-2, -dy-2, w+dx+2, h+dy+2, (red << 24) | 0xFF0000);
        ctx.getMatrices().pop();

        // Lapisan biru geser kanan/bawah
        ctx.getMatrices().push();
        ctx.getMatrices().translate(dx, dy, 0);
        ctx.fill(-dx-2, -dy-2, w+dx+2, h+dy+2, (blue << 24) | 0x0000FF);
        ctx.getMatrices().pop();

        // Penyeimbang hijau tipis di tengah
        ctx.fill(0, 0, w, h, (int)(f * 0x07) << 24 | 0x00FF00);
    }
}
