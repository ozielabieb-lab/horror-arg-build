package com.horrorarg.event;

import com.horrorarg.event.impl.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class EventManager {

    private final List<HorrorEvent> events = new ArrayList<>();
    private int gameTick = 0;

    public EventManager() {
        // ── Selalu aktif ──────────────────────────────────────────────────────
        events.add(new VignetteEvent());           // Frame gelap permanen
        events.add(new VhsGlitchEvent());          // Scanlines VHS permanen + glitch acak

        // ── 3 menit ───────────────────────────────────────────────────────────
        events.add(new GammaFlickerEvent());       // Layar gelap kilat
        events.add(new ActionBarGlitchEvent());    // Teks cryptic di action bar
        events.add(new WhiteFlashEvent());         // Kilat putih menyilaukan

        // ── 5 menit ───────────────────────────────────────────────────────────
        events.add(new SoundAnomalyEvent());       // Suara salah tempat
        events.add(new StaticOverlayEvent());      // Noise TV statis
        events.add(new FakeChatEvent());           // Pesan chat misterius
        events.add(new FootstepBehindEvent());     // Langkah kaki dari belakang

        // ── 7 menit ───────────────────────────────────────────────────────────
        events.add(new BreathingEvent());          // Napas + denyut merah
        events.add(new CornerVisionEvent());       // Sosok di sudut layar
        events.add(new ScreenTearEvent());         // Layar sobek horizontal
        events.add(new HeartbeatPulseEvent());     // Denyut jantung merah

        // ── 10 menit ─────────────────────────────────────────────────────────
        events.add(new CrypticTitleEvent());       // Title cryptic
        events.add(new ConsoleTextEvent());        // Terminal error palsu
        events.add(new DoubleVisionEvent());       // Chromatic aberration
        events.add(new WorldMemoryEvent());        // Blok berkedip warna lama

        // ── 12 menit ─────────────────────────────────────────────────────────
        events.add(new SkyDarkenEvent());          // Langit mendadak malam
        events.add(new FogCreepEvent());           // Kabut merayap dari tepi

        // ── 15 menit ─────────────────────────────────────────────────────────
        events.add(new FakeLoadingEvent());        // Layar loading palsu

        // ── Selalu cek state server ───────────────────────────────────────────
        events.add(new MobFreezeClientEvent());    // Visual saat mob beku

        // ── 30 menit ─────────────────────────────────────────────────────────
        events.add(new FakeDeathEvent());          // Layar mati palsu
    }

    public void tick(MinecraftClient client) {
        gameTick++;
        for (HorrorEvent e : events) e.tick(client, gameTick);
    }

    public void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;
        for (HorrorEvent e : events) e.render(context, client);
    }
}
