package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class WorldMemoryEvent extends HorrorEvent {
    private int totalDuration;
    private final int[] px=new int[14],py=new int[14],pw=new int[14],ph=new int[14],pc=new int[14];
    private static final int[] COLORS = {0x5D8A3C,0x7A5C3A,0x6B9BC4,0x8B6914,0x4A7A4A,0x999999,0xE8C84A};

    public WorldMemoryEvent() { super(10000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(13000) == 0) {
            int w = screenW(client), h = screenH(client);
            for (int i = 0; i < px.length; i++) {
                px[i]=random.nextInt(w); py[i]=random.nextInt(h);
                pw[i]=15+random.nextInt(50); ph[i]=15+random.nextInt(50);
                pc[i]=COLORS[random.nextInt(COLORS.length)];
            }
            totalDuration = 5 + random.nextInt(8);
            activate(totalDuration, 10000, 20000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        float f = calcAlpha(totalDuration, 2, 2);
        for (int i = 0; i < px.length; i++) {
            int a = (int)(f*(80+random.nextInt(100)));
            ctx.fill(px[i],py[i],px[i]+pw[i],py[i]+ph[i],(a<<24)|pc[i]);
        }
        int w = screenW(client), h = screenH(client);
        for (int y = 0; y < h; y += 3+random.nextInt(6)) {
            int la = (int)(f*random.nextInt(50));
            ctx.fill(0, y, w, y+1, (la<<24)|0xFFFFFF);
        }
    }
}
