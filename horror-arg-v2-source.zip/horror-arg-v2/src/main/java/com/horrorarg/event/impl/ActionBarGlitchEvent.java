package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class ActionBarGlitchEvent extends HorrorEvent {
    private static final String[] MSGS = {
        "...", "???", "do not look back.", "it\'s behind you.",
        "[CORRUPTED]", "you shouldn\'t be here.", "i see you.",
        "leave.", "don\'t.", "h e l p", "i remember you.", "stop.", "run.",
        "null", "why did you come back?"
    };

    public ActionBarGlitchEvent() { super(3600); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(5000) == 0 && client.player != null) {
            String msg = MSGS[random.nextInt(MSGS.length)];
            client.player.sendMessage(Text.of("\u00a78" + msg), true);
            activate(40, 4800, 9600);
        }
    }

    @Override public void render(DrawContext ctx, MinecraftClient client) {}
}
