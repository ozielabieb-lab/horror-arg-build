package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class GammaFlickerEvent extends HorrorEvent {
    private int totalDuration;

    public GammaFlickerEvent() { super(3600); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(6000) == 0) {
            totalDuration = 10 + random.nextInt(20);
            activate(totalDuration, 3600, 7200);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 4, 4);
        int a = (int)(f * 248);
        int color = (localTick % 4 < 2) ? (a << 24) : ((a << 24) | 0x000008);
        ctx.fill(0, 0, w, h, color);
    }
}
