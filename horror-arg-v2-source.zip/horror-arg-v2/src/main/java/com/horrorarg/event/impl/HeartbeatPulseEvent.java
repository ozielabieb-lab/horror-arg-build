package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

/**
 * Denyut jantung — layar berdenyut merah dalam ritme lub-dub.
 * Ada di sini. Sesuatu yang hidup.
 */
@Environment(EnvType.CLIENT)
public class HeartbeatPulseEvent extends HorrorEvent {

    private int totalDuration;

    public HeartbeatPulseEvent() { super(8000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(10000) == 0) {
            totalDuration = 120 + random.nextInt(80);
            activate(totalDuration, 9000, 18000);
        }
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        // Suara detak jantung setiap siklus 40 tick
        if (localTick % 40 == 0)
            client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.ENTITY_WARDEN_HEARTBEAT, 0.8f, 0.18f));
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);

        // Kurva detak: dua spike per siklus 40 tick (lub-dub)
        int mod = localTick % 40;
        float pulse;
        if      (mod < 5)  pulse = mod / 5f;
        else if (mod < 8)  pulse = (8 - mod) / 3f;
        else if (mod < 12) pulse = (mod - 8) / 4f;
        else if (mod < 15) pulse = (15 - mod) / 3f;
        else               pulse = 0f;

        float f = calcAlpha(totalDuration, 20, 20);
        int a = (int)(f * pulse * 95);
        if (a <= 0) return;

        ctx.fill(0, 0, w, h, (a << 24) | 0x660000);
        ctx.fillGradient(0, h - h/4, w, h, 0x00000000,
                         (Math.min(255, a*2) << 24) | 0x330000);
    }
}
