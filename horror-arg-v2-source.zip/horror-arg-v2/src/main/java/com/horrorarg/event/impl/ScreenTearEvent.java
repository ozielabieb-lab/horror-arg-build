package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Layar "sobek" secara horizontal — seperti sinyal video korup.
 * Garis putih muncul dan strip di bawahnya tergeser.
 */
@Environment(EnvType.CLIENT)
public class ScreenTearEvent extends HorrorEvent {

    private int tearY, offset, totalDuration;

    public ScreenTearEvent() { super(9000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (random.nextInt(12000) == 0) {
            int h = screenH(client);
            tearY        = h / 4 + random.nextInt(h / 2);
            offset       = (random.nextBoolean() ? 1 : -1) * (4 + random.nextInt(14));
            totalDuration = 15 + random.nextInt(35);
            activate(totalDuration, 9000, 18000);
        }
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client);
        float f = calcAlpha(totalDuration, 3, 3);
        int a = (int)(f * 190);

        // Garis sobekan utama
        ctx.fill(0, tearY, w, tearY + 2, (a << 24) | 0xFFFFFF);

        // Noise statis di sekitar sobekan
        for (int i = 0; i < 50; i++) {
            int nx = random.nextInt(w);
            int nb = 80 + random.nextInt(175);
            int na = (int)(f * (40 + random.nextInt(110)));
            ctx.fill(nx, tearY - 2, nx + 2 + random.nextInt(10), tearY + 5,
                     (na << 24) | (nb << 16) | (nb << 8) | nb);
        }

        // Strip gambar tergeser di bawah sobekan
        ctx.getMatrices().push();
        ctx.getMatrices().translate(offset, 0, 0);
        ctx.fill(-Math.abs(offset)-4, tearY+2, w+Math.abs(offset)+4, tearY+5,
                 (a/2) << 24 | 0x777777);
        ctx.getMatrices().pop();
    }
}
