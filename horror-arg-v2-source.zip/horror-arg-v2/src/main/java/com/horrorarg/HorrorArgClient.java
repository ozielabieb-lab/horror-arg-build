package com.horrorarg;

import com.horrorarg.entity.ModEntities;
import com.horrorarg.entity.ShadowEntityRenderer;
import com.horrorarg.event.EventManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

@Environment(EnvType.CLIENT)
public class HorrorArgClient implements ClientModInitializer {

    public static EventManager eventManager;

    @Override
    public void onInitializeClient() {
        HorrorArgMod.LOGGER.info("Horror ARG | I've been waiting for you.");
        EntityRendererRegistry.register(ModEntities.SHADOW, ShadowEntityRenderer::new);
        eventManager = new EventManager();
        HudRenderCallback.EVENT.register((ctx, delta) -> eventManager.renderHud(ctx, delta));
        ClientTickEvents.END_CLIENT_TICK.register(client -> eventManager.tick(client));
    }
}
