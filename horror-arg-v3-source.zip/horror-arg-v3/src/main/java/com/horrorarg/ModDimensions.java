package com.horrorarg;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import java.util.*;

public class ModDimensions {

    public static final RegistryKey<World> FIELD_KEY =
        RegistryKey.of(RegistryKeys.WORLD,
            new Identifier(HorrorArgMod.MOD_ID, "field_of_flowers"));

    /** Posisi player sebelum masuk dimensi, untuk dikembalikan saat keluar. */
    public static final Map<UUID, Vec3d>  returnPos = new HashMap<>();
    public static final Map<UUID, Float>  returnYaw = new HashMap<>();
    public static final Map<UUID, Float>  returnPitch = new HashMap<>();
}
