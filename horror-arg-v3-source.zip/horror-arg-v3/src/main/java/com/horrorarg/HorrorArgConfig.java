package com.horrorarg;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;

/**
 * Config disimpan di config/horrorarg.json
 * Edit langsung file tersebut untuk mengatur semua parameter.
 */
public class HorrorArgConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static HorrorArgConfig instance;

    // ── Event timing ──────────────────────────────────────────────────────────
    /** 0.5 = jarang, 1.0 = normal, 2.0 = sering, 0.0 = nonaktif */
    public float eventFrequency   = 1.0f;

    // ── Entity spawn ──────────────────────────────────────────────────────────
    /** 0.0 = tidak pernah, 0.3 = sangat jarang, 1.0 = normal */
    public float shadowSpawnRate  = 0.25f;

    // ── Void Gate block ───────────────────────────────────────────────────────
    /** 0.0 = tidak pernah, 0.3 = jarang, 1.0 = normal */
    public float voidGateRate     = 0.35f;

    // ── Enable/disable fitur ──────────────────────────────────────────────────
    public boolean enableMobStaring   = true;
    public boolean enableShadowEntity = true;
    public boolean enableVoidGate     = true;
    public boolean enableVhsEffect    = true;
    public boolean enableSoundEvents  = true;
    public boolean enableChatEvents   = true;
    public boolean enableScreenEffects = true;

    // ── Singleton ─────────────────────────────────────────────────────────────
    public static HorrorArgConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        File f = new File("config/horrorarg.json");
        if (f.exists()) {
            try (FileReader r = new FileReader(f)) {
                instance = GSON.fromJson(r, HorrorArgConfig.class);
                if (instance == null) instance = new HorrorArgConfig();
            } catch (Exception e) {
                HorrorArgMod.LOGGER.warn("Config load failed, using defaults.");
                instance = new HorrorArgConfig();
            }
        } else {
            instance = new HorrorArgConfig();
            save();
        }
        HorrorArgMod.LOGGER.info("Horror ARG | Config loaded. eventFreq=" + instance.eventFrequency);
    }

    public static void save() {
        try {
            File f = new File("config/horrorarg.json");
            f.getParentFile().mkdirs();
            try (FileWriter w = new FileWriter(f)) {
                GSON.toJson(instance, w);
            }
        } catch (Exception e) {
            HorrorArgMod.LOGGER.error("Config save failed: " + e.getMessage());
        }
    }
}
