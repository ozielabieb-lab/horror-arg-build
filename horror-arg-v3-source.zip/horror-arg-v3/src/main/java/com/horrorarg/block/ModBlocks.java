package com.horrorarg.block;

import com.horrorarg.HorrorArgMod;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static Block VOID_GATE;

    public static void register() {
        VOID_GATE = Registry.register(
            Registries.BLOCK,
            new Identifier(HorrorArgMod.MOD_ID, "void_gate"),
            new VoidGateBlock(
                AbstractBlock.Settings.create()
                    .mapColor(MapColor.BLACK)
                    .strength(50f, 1200f)
            )
        );
        Registry.register(
            Registries.ITEM,
            new Identifier(HorrorArgMod.MOD_ID, "void_gate"),
            new BlockItem(VOID_GATE, new Item.Settings())
        );
    }
}