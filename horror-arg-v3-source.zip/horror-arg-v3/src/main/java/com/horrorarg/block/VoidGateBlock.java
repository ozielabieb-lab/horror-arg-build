package com.horrorarg.block;

import com.horrorarg.HorrorArgMod;
import com.horrorarg.ModDimensions;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.Set;

/**
 * Blok hitam pekat yang sangat jarang muncul di dunia.
 * Saat diinjak:
 *   - Dari overworld → teleport ke Field of Flowers.
 *   - Dari Field of Flowers → kembali ke posisi semula.
 */
public class VoidGateBlock extends Block {

    // Delay kecil agar tidak langsung aktif saat spawn
    private static final int STEP_COOLDOWN_TICKS = 20;

    public VoidGateBlock(Settings settings) { super(settings); }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        super.onSteppedOn(world, pos, state, entity);
        if (world.isClient()) return;
        if (!(entity instanceof ServerPlayerEntity player)) return;

        ServerWorld sw = (ServerWorld) world;

        if (sw.getRegistryKey().equals(ModDimensions.FIELD_KEY)) {
            // ── Keluar dari Field of Flowers ─────────────────────────────────
            var rp = ModDimensions.returnPos.remove(player.getUuid());
            float  ry = ModDimensions.returnYaw.remove(player.getUuid())   != null
                       ? ModDimensions.returnYaw.get(player.getUuid())   : player.getYaw();
            float  rpi= ModDimensions.returnPitch.remove(player.getUuid()) != null
                       ? ModDimensions.returnPitch.get(player.getUuid()) : player.getPitch();

            ServerWorld overworld = sw.getServer().getOverworld();
            double x = rp != null ? rp.x : 0;
            double y = rp != null ? rp.y : 64;
            double z = rp != null ? rp.z : 0;

            player.teleport(overworld, x, y + 0.2, z, Set.of(), ry, rpi);
            player.sendMessage(Text.of("\u00a77You wake up. The flowers are gone."), false);

        } else {
            // ── Masuk ke Field of Flowers ────────────────────────────────────
            ServerWorld field = sw.getServer().getWorld(ModDimensions.FIELD_KEY);
            if (field == null) {
                HorrorArgMod.LOGGER.warn("Field of Flowers dimension not found!");
                return;
            }

            ModDimensions.returnPos.put(player.getUuid(), player.getPos());
            ModDimensions.returnYaw.put(player.getUuid(), player.getYaw());
            ModDimensions.returnPitch.put(player.getUuid(), player.getPitch());

            // Tempatkan void gate untuk kembali di field (di atas bedrock)
            BlockPos gatePos = new BlockPos(0, 4, 0);
            if (!field.getBlockState(gatePos).isOf(ModBlocks.VOID_GATE)) {
                field.setBlockState(gatePos, ModBlocks.VOID_GATE.getDefaultState());
            }

            player.teleport(field, 0.5, 5.0, 0.5, Set.of(), player.getYaw(), player.getPitch());
            player.sendMessage(Text.of("\u00a7d\u00a7o..."), false);
        }
    }
}
