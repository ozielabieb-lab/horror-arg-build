package com.horrorarg;

import com.horrorarg.block.ModBlocks;
import com.horrorarg.block.VoidGateBlock;
import com.horrorarg.entity.ModEntities;
import com.horrorarg.entity.ShadowEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class HorrorArgMod implements ModInitializer {

    public static final String MOD_ID = "horrorarg";
    public static final Logger LOGGER  = LoggerFactory.getLogger(MOD_ID);

    // ── Global state ──────────────────────────────────────────────────────────
    public static volatile boolean mobsStaring = true;
    public static volatile boolean mobsFrozen  = false;

    private static final Random RANDOM = new Random();

    // Freeze
    private static int freezeLeft     = 0;
    private static int freezeCooldown = 0;
    // Shadow
    private static int shadowCooldown = 0;
    // Grave markers: armorstand UUID → despawn tick
    private static final Map<UUID, Integer> graveMarkers = new HashMap<>();
    private static int graveCooldown  = 0;

    // Timings (base, modified by config)
    private static final int FREEZE_START    = 24000;
    private static final int SHADOW_START    = 18000;
    private static final int GRAVE_START     = 20000;

    private int tick = 0;

    @Override
    public void onInitialize() {
        HorrorArgConfig.load();
        LOGGER.info("Horror ARG | Something is already here...");

        ModBlocks.register();
        ModEntities.register();
        FabricDefaultAttributeRegistry.register(ModEntities.SHADOW, ShadowEntity.createAttributes());

        ServerTickEvents.END_WORLD_TICK.register(this::onWorldTick);
        ServerChunkEvents.CHUNK_LOAD.register(this::onChunkLoad);
    }

    // ── Chunk load: jarang tempatkan void gate di permukaan ──────────────────
    private void onChunkLoad(ServerWorld world, net.minecraft.world.chunk.WorldChunk chunk) {
        if (!HorrorArgConfig.get().enableVoidGate) return;
        float rate = HorrorArgConfig.get().voidGateRate;
        if (rate <= 0f) return;
        // ~0.15% per chunk pada rate 1.0 (sangat jarang)
        if (RANDOM.nextFloat() > rate * 0.0015f) return;
        // Tidak spawn di dimensi Field of Flowers
        if (world.getRegistryKey().equals(ModDimensions.FIELD_KEY)) return;

        int cx = chunk.getPos().getStartX() + RANDOM.nextInt(16);
        int cz = chunk.getPos().getStartZ() + RANDOM.nextInt(16);
        int cy = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, cx, cz);
        BlockPos pos = new BlockPos(cx, cy, cz);

        if (world.getBlockState(pos).isAir()
                && world.getBlockState(pos.down()).isSolid()
                && world.getBlockState(pos.up()).isAir()) {
            world.setBlockState(pos, ModBlocks.VOID_GATE.getDefaultState());
            LOGGER.info("Horror ARG | Void gate placed at " + pos);
        }
    }

    // ── World tick ────────────────────────────────────────────────────────────
    private void onWorldTick(ServerWorld world) {
        tick++;

        // Mob freeze
        if (mobsFrozen) {
            freezeLeft--;
            for (ServerPlayerEntity p : world.getPlayers()) {
                world.getEntitiesByClass(PassiveEntity.class,
                        p.getBoundingBox().expand(64, 16, 64), e -> !e.isDead()
                ).forEach(mob -> {
                    mob.getNavigation().stop();
                    mob.setVelocity(0, mob.getVelocity().y, 0);
                });
            }
            if (freezeLeft <= 0) {
                mobsFrozen    = false;
                freezeCooldown = cooldown(24000, 6000);
            }
        } else if (freezeCooldown > 0) {
            freezeCooldown--;
        } else if (tick > FREEZE_START && chance(15000)) {
            mobsFrozen = true;
            freezeLeft = 160 + RANDOM.nextInt(240);
        }

        // Shadow entity spawn
        if (shadowCooldown > 0) {
            shadowCooldown--;
        } else if (tick > SHADOW_START && chanceMult(20000, HorrorArgConfig.get().shadowSpawnRate)) {
            spawnShadow(world);
        }

        // Grave markers: despawn dulu yang sudah expired
        if (!graveMarkers.isEmpty()) {
            List<UUID> expired = new ArrayList<>();
            graveMarkers.forEach((id, despawnTick) -> {
                if (tick >= despawnTick) {
                    expired.add(id);
                    world.getEntitiesByType(EntityType.ARMOR_STAND,
                            world.getWorldBorder().asBox() != null ? world.getWorldBorder().asBox() : new net.minecraft.util.math.Box(-30000000, -64, -30000000, 30000000, 320, 30000000), e -> e.getUuid().equals(id))
                        .forEach(e -> e.discard());
                }
            });
            expired.forEach(graveMarkers::remove);
        }

        // Grave spawn
        if (graveCooldown > 0) {
            graveCooldown--;
        } else if (tick > GRAVE_START && chanceMult(28000, HorrorArgConfig.get().eventFrequency)) {
            spawnGraves(world);
        }
    }

    // ── Shadow spawn ──────────────────────────────────────────────────────────
    private void spawnShadow(ServerWorld world) {
        if (!HorrorArgConfig.get().enableShadowEntity) return;
        for (ServerPlayerEntity player : world.getPlayers()) {
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double dist  = 35 + RANDOM.nextDouble() * 25;
            double x = player.getX() + Math.cos(angle) * dist;
            double z = player.getZ() + Math.sin(angle) * dist;

            ShadowEntity s = new ShadowEntity(ModEntities.SHADOW, world);
            s.setPosition(x, player.getY(), z);
            world.spawnEntity(s);
            shadowCooldown = cooldown(20000, 10000);
            LOGGER.info("Horror ARG | Shadow spawned.");
            break;
        }
    }

    // ── Grave markers ─────────────────────────────────────────────────────────
    private static final String[] GRAVE_NAMES = {
    "\u00a78R.I.P. OldFriend2011 | \u00a78????????",
    "\u00a78e r r o r | \u00a78???-????",
    "\u00a78_ _ _ | \u00a78Before you came back",
    "\u00a78UNKNOWN | \u00a78Still here",
    "\u00a78Visitor | \u00a782011-????",
};

    private void spawnGraves(ServerWorld world) {
        for (ServerPlayerEntity player : world.getPlayers()) {
            int count = 2 + RANDOM.nextInt(3);
            for (int i = 0; i < count; i++) {
                double angle = RANDOM.nextDouble() * Math.PI * 2;
                double dist  = 8 + RANDOM.nextDouble() * 20;
                double x = player.getX() + Math.cos(angle) * dist;
                double z = player.getZ() + Math.sin(angle) * dist;
                int    y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int)x, (int)z);

                ArmorStandEntity stand = new ArmorStandEntity(world, x, y, z);
                stand.setCustomName(Text.of(GRAVE_NAMES[RANDOM.nextInt(GRAVE_NAMES.length)]));
                stand.setCustomNameVisible(true);
                stand.setInvisible(true);
                stand.setInvulnerable(true);
                stand.setNoGravity(true);
                world.spawnEntity(stand);
                // Hapus setelah 60 detik
                graveMarkers.put(stand.getUuid(), tick + 1200);
            }
            graveCooldown = cooldown(28000, 12000);
            break;
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private boolean chance(int base) {
        float freq = HorrorArgConfig.get().eventFrequency;
        if (freq <= 0) return false;
        return RANDOM.nextInt(Math.max(1, (int)(base / freq))) == 0;
    }

    private boolean chanceMult(int base, float multiplier) {
        if (multiplier <= 0) return false;
        return RANDOM.nextInt(Math.max(1, (int)(base / multiplier))) == 0;
    }

    private int cooldown(int min, int rng) {
        return min + RANDOM.nextInt(Math.max(1, rng));
    }

    public static void onPassiveMobDied() {
        if (mobsStaring && HorrorArgConfig.get().enableMobStaring) {
            mobsStaring = false;
            LOGGER.info("Horror ARG | Staring stopped.");
        }
    }
}
