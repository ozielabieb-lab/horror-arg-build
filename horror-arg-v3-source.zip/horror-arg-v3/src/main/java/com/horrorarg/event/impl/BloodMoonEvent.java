package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Di malam hari, bulan tiba-tiba menjadi merah darah dan tampak lebih besar.
 * Atmosfer langit ikut memerah. Lalu perlahan kembali normal.
 * Hanya aktif saat malam (tick 13000-23000).
 * Mulai setelah 15 menit.
 */
@Environment(EnvType.CLIENT)
public class BloodMoonEvent extends HorrorEvent {

    private int totalDuration;

    public BloodMoonEvent() { super(18000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (!shouldTrigger(22000) || !shouldTriggerScreen()) return;
        if (client.world == null) return;

        // Hanya saat malam
        long time = client.world.getTimeOfDay() % 24000;
        if (time < 13000 || time > 23000) return;

        totalDuration = 300 + random.nextInt(200); // 15-25 detik
        activate(totalDuration, 16000, 28000);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        if (client.world == null) return;

        // Cek masih malam
        long time = client.world.getTimeOfDay() % 24000;
        if (time < 12000 || time > 24000) return;

        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 30, 30);

        // Atmosfer merah tipis di langit (bagian atas layar)
        int skyA = (int)(f * 60);
        ctx.fillGradient(0, 0, w, h / 2, (skyA << 24) | 0x880000, 0x00000000);

        // "Bulan" merah — lingkaran besar di area atas tengah
        int moonX = w / 2;
        int moonY = (int)(h * 0.18f);
        int moonR = (int)(f * 22) + 16;
        int moonA = (int)(f * 200);

        // Aura luar
        for (int r = moonR + 10; r >= moonR; r--) {
            int auraA = (int)(moonA * 0.4f * (1f - (float)(r - moonR) / 10f));
            drawCircle(ctx, moonX, moonY, r, (auraA << 24) | 0xAA0000);
        }
        // Badan bulan
        for (int r = moonR; r >= 0; r--) {
            int innerA = moonA - (int)(moonA * 0.3f * r / moonR);
            drawCircle(ctx, moonX, moonY, r, (innerA << 24) | 0xCC1100);
        }
    }

    /** Gambar lingkaran sebagai strip horizontal. */
    private void drawCircle(DrawContext ctx, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int)Math.sqrt(Math.max(0, r*r - dy*dy));
            ctx.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, color);
        }
    }
}
