package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;

/**
 * Seperti siaran "numbers station" dari Perang Dingin.
 * Serangkaian angka acak muncul di layar, diikuti kode cryptic.
 * "4 8 15 16 23 42" — "MATI. JANGAN KEMBALI."
 * Mulai setelah 12 menit.
 */
@Environment(EnvType.CLIENT)
public class NumberStationEvent extends HorrorEvent {

    private String[] lines;
    private int      totalDuration;
    private int      lineReveal = 0;

    private static final String[] CODE_LINES = {
        "4  8  15  16  23  42",
        "01101000 01100101 01101100 01110000",
        "TRANSMISSION ORIGIN: UNKNOWN",
        "ERROR :: COORDINATES :: NaN NaN NaN",
        "MEMORY ADDRESS: 0x00000000",
        "PROCESS: old_world.exe",
        "STATUS: STILL RUNNING",
        "YOU ARE BEING OBSERVED",
        "OBSERVATION COUNT: %d",
        "END TRANSMISSION",
    };

    public NumberStationEvent() { super(14400); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (!shouldTrigger(18000) || !shouldTriggerScreen()) return;
        // Pilih 4-6 baris acak
        int count = 4 + random.nextInt(3);
        lines = new String[count];
        java.util.List<String> pool = new java.util.ArrayList<>(java.util.Arrays.asList(CODE_LINES));
        java.util.Collections.shuffle(pool, random);
        for (int i = 0; i < count; i++) {
            String s = pool.get(i);
            // Isi placeholder
            if (s.contains("%d")) s = s.replace("%d", String.valueOf(random.nextInt(9000)+1000));
            lines[i] = s;
        }
        lineReveal    = 0;
        totalDuration = count * 30 + 40;
        activate(totalDuration, 14000, 24000);

        // Bunyi static/noise
        if (shouldTriggerSound())
            client.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.ENTITY_WARDEN_HEARTBEAT, 0.3f, 0.12f));
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (localTick % 30 == 1 && lineReveal < (lines == null ? 0 : lines.length))
            lineReveal++;
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active || lines == null) return;
        int w = screenW(client), h = screenH(client);

        float f = calcAlpha(totalDuration, 6, 10);
        int bg = (int)(f * 180);

        // Panel gelap di tengah
        int panelW = w * 5 / 8, panelH = lineReveal * 14 + 30;
        int panelX = (w - panelW) / 2, panelY = h / 3;
        ctx.fill(panelX - 6, panelY - 6, panelX + panelW + 6, panelY + panelH + 6,
                 (bg << 24) | 0x000000);
        ctx.fill(panelX - 6, panelY - 7, panelX + panelW + 6, panelY - 6,
                 (int)(f*255) << 24 | 0x00FF00);

        // Header
        ctx.drawText(client.textRenderer, "\u2588 INCOMING SIGNAL \u2588",
                     panelX, panelY, (int)(f*255) << 24 | 0x00FF00, false);

        // Baris angka/kode
        for (int i = 0; i < lineReveal; i++) {
            String line = lines[i];
            // Efek glitch: kadang huruf berubah
            if (random.nextInt(8) == 0) {
                char[] chars = line.toCharArray();
                int idx = random.nextInt(chars.length);
                if (chars[idx] != ' ') chars[idx] = (char)('A' + random.nextInt(26));
                line = new String(chars);
            }
            int color = i == lineReveal - 1 ? (int)(f*255) << 24 | 0xFFFF00
                                            : (int)(f*255) << 24 | 0x00CC00;
            ctx.drawText(client.textRenderer, line, panelX, panelY + (i+1)*14, color, false);
        }
    }
}
