package com.horrorarg.event;

import com.horrorarg.HorrorArgConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.Random;

@Environment(EnvType.CLIENT)
public abstract class HorrorEvent {

    protected final Random random = new Random();
    protected boolean active               = false;
    protected int     activeTicksRemaining = 0;
    protected int     cooldownTicksRemaining = 0;
    protected int     localTick            = 0;
    protected final int minGameTicks;

    protected HorrorEvent(int minGameTicks) { this.minGameTicks = minGameTicks; }

    public final void tick(MinecraftClient client, int gameTick) {
        if (client.world == null || client.player == null) return;
        if (gameTick < minGameTicks) return;

        if (active) {
            localTick++;
            activeTicksRemaining--;
            onActiveTick(client, gameTick);
            if (activeTicksRemaining <= 0) { active = false; onDeactivate(client); }
        } else if (cooldownTicksRemaining > 0) {
            cooldownTicksRemaining--;
        } else {
            checkTrigger(client, gameTick);
        }
    }

    protected abstract void checkTrigger(MinecraftClient client, int gameTick);

    protected void activate(int duration, int cdMin, int cdMax) {
        active                 = true;
        localTick              = 0;
        activeTicksRemaining   = duration;
        cooldownTicksRemaining = cdMin + random.nextInt(Math.max(1, cdMax - cdMin));
    }

    /**
     * Trigger dengan frekuensi dipengaruhi config.
     * baseChance = 1/N probabilitas per tick.
     * eventFrequency 2.0 = 2x lebih sering, 0.5 = 2x lebih jarang.
     */
    protected boolean shouldTrigger(int baseChance) {
        float freq = HorrorArgConfig.get().eventFrequency;
        if (freq <= 0f) return false;
        int adjusted = Math.max(1, (int)(baseChance / freq));
        return random.nextInt(adjusted) == 0;
    }

    protected boolean shouldTriggerSound() {
        return HorrorArgConfig.get().enableSoundEvents;
    }

    protected boolean shouldTriggerChat() {
        return HorrorArgConfig.get().enableChatEvents;
    }

    protected boolean shouldTriggerScreen() {
        return HorrorArgConfig.get().enableScreenEffects;
    }

    protected void onActiveTick(MinecraftClient client, int gameTick) {}
    protected void onDeactivate(MinecraftClient client) {}

    public abstract void render(DrawContext context, MinecraftClient client);

    protected int screenW(MinecraftClient c) { return c.getWindow().getScaledWidth();  }
    protected int screenH(MinecraftClient c) { return c.getWindow().getScaledHeight(); }

    protected float calcAlpha(int total, int fadeIn, int fadeOut) {
        if (localTick < fadeIn) return (float)localTick / Math.max(1, fadeIn);
        if (activeTicksRemaining < fadeOut) return (float)activeTicksRemaining / Math.max(1, fadeOut);
        return 1f;
    }
}
