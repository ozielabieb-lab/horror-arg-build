package com.horrorarg.event;

import com.horrorarg.HorrorArgConfig;
import com.horrorarg.event.impl.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class EventManager {

    private final List<HorrorEvent> events = new ArrayList<>();
    private int gameTick = 0;

    public EventManager() {
        // ── Selalu aktif ──────────────────────────────────────────────────────
        events.add(new VignetteEvent());               // Frame gelap permanen
        events.add(new VhsGlitchEvent());              // Scanlines VHS + glitch
        events.add(new MobFreezeClientEvent());        // Visual mob beku
        events.add(new FieldOfFlowersClientEvent());   // BARU: dimensi awareness

        // ── 3 menit ───────────────────────────────────────────────────────────
        events.add(new GammaFlickerEvent());           // Gelap kilat
        events.add(new ActionBarGlitchEvent());        // Teks cryptic action bar
        events.add(new WhiteFlashEvent());             // Kilat putih

        // ── 5 menit ───────────────────────────────────────────────────────────
        events.add(new SoundAnomalyEvent());           // Suara salah
        events.add(new StaticOverlayEvent());          // TV static
        events.add(new FakeChatEvent());               // Pesan chat misterius
        events.add(new FootstepBehindEvent());         // Langkah kaki belakang

        // ── 7 menit ───────────────────────────────────────────────────────────
        events.add(new BreathingEvent());              // Napas + denyut merah
        events.add(new CornerVisionEvent());           // Sosok di sudut
        events.add(new ScreenTearEvent());             // Layar sobek
        events.add(new HeartbeatPulseEvent());         // Detak jantung

        // ── 8 menit ───────────────────────────────────────────────────────────
        events.add(new DiaryEvent());                  // BARU: entri buku harian

        // ── 10 menit ─────────────────────────────────────────────────────────
        events.add(new CrypticTitleEvent());           // Title cryptic
        events.add(new ConsoleTextEvent());            // Terminal error palsu
        events.add(new DoubleVisionEvent());           // Chromatic aberration
        events.add(new WorldMemoryEvent());            // Blok berkedip kenangan
        events.add(new NumberStationEvent());          // BARU: siaran angka cryptic

        // ── 12 menit ─────────────────────────────────────────────────────────
        events.add(new SkyDarkenEvent());              // Langit mendadak malam
        events.add(new FogCreepEvent());               // Kabut merayap
        events.add(new OldSaveScreenEvent());          // BARU: layar save lama

        // ── 15 menit ─────────────────────────────────────────────────────────
        events.add(new FakeLoadingEvent());            // Layar loading palsu
        events.add(new BloodMoonEvent());              // BARU: bulan merah (malam)
        events.add(new SunEyeEvent());                 // BARU: mata di langit (siang)

        // ── 30 menit ─────────────────────────────────────────────────────────
        events.add(new FakeDeathEvent());              // Layar mati palsu
    }

    public void tick(MinecraftClient client) {
        gameTick++;
        for (HorrorEvent e : events) e.tick(client, gameTick);
    }

    public void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;
        for (HorrorEvent e : events) e.render(context, client);
    }
}
