package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Siang hari, dua mata gelap muncul di langit — di area matahari.
 * Mereka perlahan membuka, menatap, lalu menutup dan hilang.
 * Sangat singkat (3-5 detik). Hanya siang hari.
 * Mulai setelah 18 menit.
 */
@Environment(EnvType.CLIENT)
public class SunEyeEvent extends HorrorEvent {

    private int totalDuration;

    public SunEyeEvent() { super(21600); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (!shouldTrigger(24000) || !shouldTriggerScreen()) return;
        if (client.world == null) return;

        // Hanya siang (tick 1000-11000)
        long time = client.world.getTimeOfDay() % 24000;
        if (time < 1000 || time > 11000) return;

        totalDuration = 60 + random.nextInt(40); // 3-5 detik
        activate(totalDuration, 18000, 32000);
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;
        int w = screenW(client), h = screenH(client);

        // Mata membuka di tengah, menutup di akhir
        float openFactor;
        if (localTick < 15)                          openFactor = localTick / 15f;
        else if (activeTicksRemaining < 15)          openFactor = activeTicksRemaining / 15f;
        else                                          openFactor = 1f;

        int eyeA = (int)(openFactor * 230);
        if (eyeA <= 0) return;

        // Posisi dua mata di area langit atas (tengah layar, sekitar 20% dari atas)
        int eyeY    = (int)(h * 0.20f);
        int spacing = w / 8;
        int cx      = w / 2;

        for (int side = -1; side <= 1; side += 2) {
            int ex = cx + side * spacing;

            // Putih mata (elips lebar)
            int eyeW = 28, eyeH = (int)(18 * openFactor);
            drawEllipse(ctx, ex, eyeY, eyeW, eyeH, (eyeA << 24) | 0x111111);

            // Pupil (lingkaran kecil hitam pekat)
            if (openFactor > 0.5f) {
                int pupilA = (int)((openFactor - 0.5f) * 2 * eyeA);
                drawEllipse(ctx, ex, eyeY, 8, (int)(8 * openFactor), (pupilA << 24) | 0x000000);
            }
        }

        // Partikel kabut di sekitar mata
        if (openFactor > 0.7f) {
            int mistA = (int)((openFactor - 0.7f) / 0.3f * 40);
            ctx.fillGradient(cx - spacing*2, eyeY - 30, cx + spacing*2, eyeY + 30,
                             0x00000000, (mistA << 24) | 0x000000);
        }
    }

    private void drawEllipse(DrawContext ctx, int cx, int cy, int rx, int ry, int color) {
        if (rx <= 0 || ry <= 0) return;
        for (int dy = -ry; dy <= ry; dy++) {
            float ratio = (float)dy / ry;
            int dx = (int)(rx * Math.sqrt(Math.max(0, 1 - ratio * ratio)));
            ctx.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, color);
        }
    }
}
