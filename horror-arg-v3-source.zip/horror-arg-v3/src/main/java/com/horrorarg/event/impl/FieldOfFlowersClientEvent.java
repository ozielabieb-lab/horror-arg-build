package com.horrorarg.event.impl;

import com.horrorarg.ModDimensions;
import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Efek client saat berada di dimensi Field of Flowers:
 *  - Tint hangat nostalgik (kuning-oranye tipis) selalu ada
 *  - Pesan judul saat pertama masuk
 *  - Teks "Step on the black block to return" muncul pelan
 *  - Saat keluar dimensi, tint menghilang
 */
@Environment(EnvType.CLIENT)
public class FieldOfFlowersClientEvent extends HorrorEvent {

    private boolean wasInField    = false;
    private int     inFieldTick   = 0;
    private boolean shownTitle    = false;
    private int     titleTimer    = 0;
    private String  titleText     = "";
    private String  subtitleText  = "";

    public FieldOfFlowersClientEvent() {
        super(0);
        active               = true;
        activeTicksRemaining = Integer.MAX_VALUE;
    }

    @Override protected void checkTrigger(MinecraftClient c, int t) {}

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        if (client.world == null) return;
        boolean inField = client.world.getRegistryKey().equals(ModDimensions.FIELD_KEY);

        if (inField) {
            inFieldTick++;

            // Tampilkan pesan selamat datang sekali
            if (!shownTitle && inFieldTick > 10) {
                shownTitle   = true;
                titleText    = "...";
                subtitleText = "You remember this place.";
                titleTimer   = 100;
            }
            if (titleTimer > 0) titleTimer--;

        } else {
            // Keluar dari field
            if (wasInField) {
                shownTitle  = false;
                inFieldTick = 0;
                titleTimer  = 0;
            }
        }
        wasInField = inField;
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (client.world == null) return;
        boolean inField = client.world.getRegistryKey().equals(ModDimensions.FIELD_KEY);
        if (!inField) return;

        int w = screenW(client), h = screenH(client);

        // ── Tint hangat nostalgik (selalu ada di field) ───────────────────────
        // Kuning-oranye sangat tipis seperti foto vintage
        ctx.fill(0, 0, w, h, 0x10FFE080);
        // Sepia gradient dari bawah
        ctx.fillGradient(0, h*3/4, w, h, 0x00C87820, 0x18C87820);

        // ── Pesan judul selamat datang ────────────────────────────────────────
        if (titleTimer > 0) {
            float f;
            if      (titleTimer > 80) f = (100 - titleTimer) / 20f;
            else if (titleTimer < 15) f = titleTimer / 15f;
            else                       f = 1f;

            int a = (int)(f * 255);
            if (!titleText.isEmpty()) {
                ctx.getMatrices().push();
                ctx.getMatrices().scale(2f, 2f, 1f);
                int tw = client.textRenderer.getWidth(titleText);
                ctx.drawText(client.textRenderer, titleText,
                        (w/2 - tw)/2, h/4/2 - 10,
                        (a << 24) | 0xFFFFCC, true);
                ctx.getMatrices().pop();
            }
            if (!subtitleText.isEmpty()) {
                int sw = client.textRenderer.getWidth(subtitleText);
                ctx.drawText(client.textRenderer, subtitleText,
                        (w - sw)/2, h/2,
                        ((int)(f*200) << 24) | 0xDDCCAA, true);
            }
        }

        // ── Petunjuk kembali (setelah 5 detik di field) ───────────────────────
        if (inFieldTick > 100) {
            float hintAlpha = Math.min(1f, (inFieldTick - 100) / 60f);
            int ha = (int)(hintAlpha * 130);
            String hint = "The black block returns you home.";
            int hiw = client.textRenderer.getWidth(hint);
            ctx.drawText(client.textRenderer, hint,
                    (w - hiw)/2, h - 25,
                    (ha << 24) | 0xCCBBAA, false);
        }
    }
}
