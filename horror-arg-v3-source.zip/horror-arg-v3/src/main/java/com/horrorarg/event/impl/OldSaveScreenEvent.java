package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Layar retro "loading save lama" muncul sebentar.
 * Terasa seperti file save dari 2011 tiba-tiba ditemukan.
 * Progres bar bergerak, teks mengetik sendiri, lalu fade.
 * Mulai setelah 10 menit.
 */
@Environment(EnvType.CLIENT)
public class OldSaveScreenEvent extends HorrorEvent {

    private static final String[] LINES = {
        "World file detected: old_world.dat",
        "Last accessed: 4,127 days ago",
        "Player data: present",
        "Entities: unexpected count",
        "Restoring memory...",
    };

    private int   totalDuration;
    private int   visibleLines = 0;
    private float barProgress  = 0f;
    private boolean done       = false;

    public OldSaveScreenEvent() { super(12000); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (!shouldTrigger(20000) || !shouldTriggerScreen()) return;
        totalDuration = 180;
        visibleLines  = 0;
        barProgress   = 0f;
        done          = false;
        activate(totalDuration, 18000, 32000);
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        // Tambah baris teks setiap 20 tick
        if (localTick % 20 == 1 && visibleLines < LINES.length)
            visibleLines++;

        // Progres bar naik pelan
        if (!done) barProgress = Math.min(1f, barProgress + 0.005f);

        if (barProgress >= 1f && !done) done = true;
    }

    @Override
    public void render(DrawContext ctx, MinecraftClient client) {
        if (!active) return;

        int w = screenW(client), h = screenH(client);
        float f = calcAlpha(totalDuration, 10, 20);
        int bg = (int)(f * 245), fg = (int)(f * 255);

        // Background hitam
        ctx.fill(0, 0, w, h, bg << 24);

        int lineH  = client.textRenderer.fontHeight + 4;
        int startY = h / 3;
        int panelW = w * 2 / 3;
        int panelX = (w - panelW) / 2;

        // Header
        String header = "> LOADING SAVE DATA <";
        int hw = client.textRenderer.getWidth(header);
        ctx.drawText(client.textRenderer, header, (w - hw) / 2, startY - lineH * 2,
                     (fg << 24) | 0x00FF00, false);

        // Baris teks mengetik sendiri
        for (int i = 0; i < visibleLines && i < LINES.length; i++) {
            String line = (i == visibleLines - 1 && localTick % 6 < 3)
                    ? LINES[i] + "_"   // kursor berkedip di baris terakhir
                    : LINES[i];
            int color = i == LINES.length - 1 ? (fg << 24) | 0xFFFF44 : (fg << 24) | 0xAAAAAA;
            ctx.drawText(client.textRenderer, line, panelX, startY + i * lineH, color, false);
        }

        // Progress bar
        int barY = startY + LINES.length * lineH + 12;
        ctx.fill(panelX, barY, panelX + panelW, barY + 6, (fg << 24) | 0x222222);
        ctx.fill(panelX, barY, panelX + (int)(panelW * barProgress), barY + 6,
                 (fg << 24) | 0x00FF00);

        // Pesan selesai
        if (done && activeTicksRemaining > 15) {
            String complete = "Restoration complete. Welcome back.";
            int cw = client.textRenderer.getWidth(complete);
            ctx.drawText(client.textRenderer, complete, (w - cw) / 2, barY + 18,
                         (fg << 24) | 0xFFFFFF, false);
        }
    }
}
