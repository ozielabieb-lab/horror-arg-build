package com.horrorarg.event.impl;

import com.horrorarg.event.HorrorEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * Entri buku harian muncul di chat, diketik pelan satu per satu.
 * Terasa seperti seseorang yang merekam kejadian di dunia ini.
 * Cerita yang semakin gelap seiring waktu.
 * Mulai setelah 8 menit.
 */
@Environment(EnvType.CLIENT)
public class DiaryEvent extends HorrorEvent {

    private static final String[][][] ENTRIES = {
        {
            {"\u00a77[Day 1] \u00a7fI came back today."},
            {"\u00a77[Day 1] \u00a7fEverything is exactly as I left it."},
            {"\u00a77[Day 1] \u00a7fThe animals won\'t stop staring at me."},
        },
        {
            {"\u00a77[Day 4] \u00a7fI heard footsteps last night."},
            {"\u00a77[Day 4] \u00a7fJust outside. I checked. Nothing was there."},
            {"\u00a77[Day 4] \u00a7fI think it was checking on me."},
        },
        {
            {"\u00a77[Day 9] \u00a7fI tried to dig down today."},
            {"\u00a77[Day 9] \u00a7fThere was something already beneath the surface."},
            {"\u00a77[Day 9] \u00a7fI filled it back in."},
        },
        {
            {"\u00a77[Day 15] \u00a7fIt has been here since before I built anything."},
            {"\u00a77[Day 15] \u00a7fI think this is its world. Not mine."},
            {"\u00a77[Day 15] \u00a7fI need to leave. But I can\'t find the edge."},
        },
        {
            {"\u00a77[Day ??] \u00a7fI don\'t remember coming back."},
            {"\u00a77[Day ??] \u00a7fI don\'t remember leaving."},
            {"\u00a77[Day ??] \u00a7fI think I never did."},
        },
    };

    private int  entryIdx    = 0;
    private int  lineIdx     = 0;
    private int  lineTimer   = 0;

    public DiaryEvent() { super(9600); }

    @Override
    protected void checkTrigger(MinecraftClient client, int gameTick) {
        if (!shouldTrigger(14000) || !shouldTriggerChat()) return;
        lineIdx   = 0;
        lineTimer = 0;
        activate(ENTRIES[entryIdx].length * 50, 12000, 22000);
    }

    @Override
    protected void onActiveTick(MinecraftClient client, int gameTick) {
        lineTimer++;
        // Kirim satu baris setiap 50 tick (~2.5 detik)
        if (lineTimer % 50 == 1 && lineIdx < ENTRIES[entryIdx].length && client.player != null) {
            client.player.sendMessage(Text.of(ENTRIES[entryIdx][lineIdx][0]), false);
            lineIdx++;
            if (lineIdx >= ENTRIES[entryIdx].length) {
                entryIdx = (entryIdx + 1) % ENTRIES.length;
            }
        }
    }

    @Override public void render(DrawContext ctx, MinecraftClient client) {}
}
